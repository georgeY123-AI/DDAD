# AI usage log

Project: `P03` · Version: team · Members: Gabriel George Youssef Mikhail (A8HSG9), [second member]

> Draft started from the real work of Member 1. Edit the entries in your own words and add the entries of Member 2.
> Only things that really happened belong here.

## Tools used

| Tool | Used for (examples) |
|---|---|
| Claude (Anthropic) — Member 1 | project analysis and plan; first drafts of the Python modules, the SQL queries and their tests; the README and handoff documents; cross-checking results (Q1/Q2, extractions) |
| [tool] — Member 2 | TODO (for example Power Fx formulas, flow expressions) |

## Checked or corrected AI answers (at least 3)

### 1. Query markers in `sql/queries.sql` were too greedy
- **Component:** Python / SQL
- **What we asked:** write the code that splits `queries.sql` into reports at the marker lines `-- Q1`, `-- Q2`, …
- **What the AI suggested:** a pattern that treated any single-word comment line (`-- intro`) as the start of a new query.
- **What was wrong or missing:** a harmless comment would silently become a "query" and break the split.
- **How we checked it:** a unit test with a comment line before the first marker failed.
- **What we used in the end:** a pattern that accepts only `-- Q<number>` and `-- PRECISION`.

### 2. The AI's own check of the SQL result was wrong for a duplicate ID
- **Component:** SQL / verification
- **What we asked:** verify our real `Q1.csv` and `Q2.csv` independently.
- **What the AI suggested:** a script that recomputed all order values from the data file by `PurchaseID`.
- **What was wrong or missing:** the data file contains `PO-5006` twice (the second row is a rejected duplicate); the script used the
  later, rejected row and reported a mismatch for that ID.
- **How we checked it:** we recomputed that order by hand with the accepted (first) row: 11 × 27.77 × 312.51 = 95,462, which equals the pipeline's value.
- **What we used in the end:** the pipeline's result was correct; the validation rule "the earlier row keeps its result" is what the script had ignored.

### 3. The first full Gemini run showed no progress
- **Component:** Python / Gemini
- **What we asked:** run the extraction for all records and the dev set.
- **What the AI suggested:** a run that printed nothing while about 60 requests were made (with pauses and retries).
- **What was wrong or missing:** the terminal looked frozen for minutes; the Google library also printed a harmless notice.
- **How we checked it:** the prompt never came back, so the program was still running; waiting showed it was not stuck.
- **What we used in the end:** progress lines (`[12/61] ok`, retry messages), silenced the library notice, and kept saving each answer to the cache so a stopped run loses nothing.

### 4. The API key can be saved with quotes on Windows
- **Component:** Python / environment
- **What we asked:** how to store the Gemini key in an environment variable.
- **What the AI suggested:** a `setx` command with the key in quotes.
- **What was wrong or missing:** depending on how the variable is set on Windows, the quote characters can become part of the key.
- **How we checked it:** a small script prints the key's length and whether quotes were saved, without printing the key.
- **What we used in the end:** the code removes surrounding quotes and spaces; `check_gemini.py` checks the key with one real request.

## Parts written without AI (optional)
TODO.
