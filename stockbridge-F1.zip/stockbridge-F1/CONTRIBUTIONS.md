# Contributions

Project P03 StockBridge, team version (two members).

## Who did what

| Part | Member 1 — Gabriel George Youssef Mikhail (A8HSG9) | Member 2 — [name, ID] |
|---|---|---|
| Python pipeline, validation, API client | built and tested | |
| SQLite, SQL reports Q1–Q5, precision query | built and tested | |
| Gemini extraction and dev-set evaluation | built; ran it with his own key | |
| Rules, flags, cases | built and tested | |
| Review import, precision, R3 tuning (code) | built and tested | |
| SharePoint list, Power Apps app | | TODO |
| Flows F1, F2, F3 | run-report sender (Python) | TODO flows |
| Extension X4 data-quality report | built | |
| Extension X6 continuous integration | built | TODO: evidence (badge, failing + fixed run) |
| Review of cases (about a third each) | TODO | TODO |
| README, AI usage log | sections 1–6, 9–10 drafted | TODO sections 7, 8 |

## Cross-checks (each member checks a part of the other member)

| Checked by | Part checked | What was checked | Result |
|---|---|---|---|
| Member 2 | e.g. Python pipeline | run `pytest` and `python main.py` from a fresh clone | TODO |
| Member 1 | e.g. app and flows | go through the review screen and a flow run history | TODO |

Fill in the TODO cells with what really happened.
