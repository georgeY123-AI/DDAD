# P03 — StockBridge: purchase proposals and stock review (team version)

Members: Gabriel George Youssef Mikhail (A8HSG9), [second member: name, ID]
Course: Data-driven Application Development, MSc Data Science, University of Debrecen.
Instructor: Marcell Beregi-Kovács (confirmed: a two-person group solves the **team** version; there is no demo).

[![CI](https://github.com/OWNER/REPO/actions/workflows/ci.yml/badge.svg)](https://github.com/OWNER/REPO/actions/workflows/ci.yml)
<!-- TODO: replace OWNER/REPO with the real repository (extension X6) -->

> Living document: every part updates its own section with **real** results only. **TODO** = not done yet.

## Status of the parts

| Part | Owner | Status |
|---|---|---|
| Validation, API client, SQLite, SQL reports Q1–Q5 | Member 1 | done, tested, real runs OK |
| Gemini extraction + dev-set evaluation | Member 1 | done; real run: 60/60 ok, dev accuracy 10/10 on all fields |
| Rules R1–R5, flags, cases | Member 1 | done, tested; **TODO: paste the numbers of the real run in section 4** |
| Review import, precision per rule, R3 tuning (code) | Member 1 | done, tested with fakes; **real review data: TODO** |
| Run-report sender for flow F1 (`--send-report`) | Member 1 | done, tested with fakes; **real flow: TODO (needs F1)** |
| Extension X4 data-quality report, X6 CI | Member 1 | code done; **evidence: TODO** (see section 9) |
| SharePoint list, Power Apps app, flows F1/F2/F3 | Member 2 | TODO — see `powerplatform/SPEC.md` |
| Review of every case, README sections 7–8, `CONTRIBUTIONS.md` | both | TODO |

## 1. Architecture

```text
data/*.csv ─► validate ─► Frankfurter API (cache) ─► order value in HUF ─┐
     │                                                                   ▼
     │                         Gemini (cache) ─► extractions ─► rules R1–R5 ─► flags.csv ─► cases.csv
     ▼                                                                   │                      │
rejected_rows.csv                       SQLite project.sqlite ◄──────────┘                      │
                                              │                                                  ▼
                              SQL reports Q1–Q5, PRECISION            SharePoint list ─► Power Apps app ─► F2 approval flow
                                                                       (Member 2)
run report (JSON) ──HTTP──► F1 flow ──► Excel table tblProjectRuns + receipt        (--send-report)

Team loop: export list ─► --import-reviews ─► reviews.csv ─► precision per rule ─► tuned R3 ─► output/tuned/
```

## 2. Setup

- Python 3.11 or newer (developed on 3.10–3.13).
- ```
  python -m venv .venv
  .venv\Scripts\activate           # macOS/Linux: source .venv/bin/activate
  python -m pip install -r requirements.txt
  ```
- Environment variables (names only, never values, never in Git):
  `GEMINI_API_KEY` (Gemini), `GEMINI_MODEL` (optional model name), `FLOW_URL` (HTTP URL of flow F1).
- Check the Gemini setup: `python check_gemini.py` (one small request; never prints the key).
- Power Platform: list `P03 Review Queue`; app and flow names — TODO (Member 2).

## 3. Commands

| Purpose | Command |
|---|---|
| Full local pipeline | `python main.py --scope team` |
| Tests (241) | `pytest` |
| Lint | `ruff check .` |
| Send the run report (F1) | `python main.py --scope team --send-report` |
| Send the same report again (flow must answer `duplicate`) | `python main.py --scope team --resend-last-report` |
| Import the review decisions (exported list) | `python main.py --scope team --import-reviews <exported file>` |
| Run with the tuned R3 threshold → `output/tuned/` | `python main.py --scope team --r3-tolerance <days>` |
| Data-quality report (X4) | `python main.py --scope team --data-quality` |
| Gemini model / pause between calls | `--model <name>`, `--gemini-pause <seconds>` |

Deleting `output/api_cache/` forces fresh API calls; deleting `output/llm_cache.json` forces fresh Gemini calls.
A normal run never sends anything to the flow. The default threshold of R3 is the brief's rule (tolerance 0).

## 4. Results of the final run

Real values so far (team file):
- Rows / accepted / rejected: 66 / 60 / 6 (MISSING_ID, DUPLICATE_ID, UNKNOWN_REFERENCE, INVALID_DATE, 2 × INVALID_VALUE).
- Exchange rates: 45 (currency, date) pairs; the rerun made 0 calls. 15 non-HUF orders use an earlier `RateDate` (weekends).
- Gemini: 60 ok, 0 failed. Q3 (R3 in SQL): 11 proposals.
- Flags per rule and cases (High / Medium): **TODO — paste the output line `flags per rule: ...` of the final run.**

## 5. Database schema

```mermaid
erDiagram
    products  ||--o{ purchases : "ProductID"
    suppliers ||--o{ purchases : "SupplierID"
    purchases ||--|| order_values : "PurchaseID"
    purchases ||--|| extractions : "PurchaseID = RecordID"
    purchases ||--o{ flags : "PurchaseID = RecordID"
    purchases ||--o| cases : "PurchaseID = CaseID"
    cases ||--o| reviews : "CaseID"
    cases ||--o{ review_codes : "CaseID"
    products  { text ProductID PK  text ProductName  text Category  int TargetStock  int MaxOrderHUF }
    suppliers { text SupplierID PK  text SupplierName  text Country  text PreferredCurrency  int LeadDays }
    purchases { text PurchaseID PK  text ProductID FK  text SupplierID FK  text OrderDate  int Quantity  real UnitPrice  text Currency  int StockOnHand  int WeeklyDemand  text SupplierMessage }
    api_rates { text Currency PK  text RequestDate PK  text RateDate  real RateToHUF }
    order_values { text PurchaseID PK_FK  int OrderValueHUF }
    extractions { text RecordID PK_FK  int delay_days  text partial_delivery  real price_increase_pct  text ExtractionStatus }
    flags { text RecordID PK_FK  text RuleID PK  text ReasonCode  text Severity  real RiskScore }
    cases { text CaseID PK_FK  text Severity  real RiskScore  text ReasonCodes  text Status  text ProductName  text SupplierName  text Currency  int OrderValueHUF  int delay_days }
    reviews { text CaseID PK_FK  text ReviewDecision  text ConfirmedCodes  text ReviewerNotes }
    review_codes { text CaseID PK_FK  text ReasonCode PK }
```

`api_rates` is joined to `purchases` on (Currency, OrderDate = RequestDate) with a LEFT JOIN; HUF has no rows (rate 1).
The database is rebuilt from scratch in every run (no duplicates after a rerun).

## 6. Gemini extraction

- Model: `gemini-3.1-flash-lite` (default; `--model` to change). Key from `GEMINI_API_KEY`.
- Input: `SupplierMessage` of every accepted record. Output: `delay_days` (integer, weeks → days), `partial_delivery`
  (boolean), `price_increase_pct` (number).
- Structured output: the JSON schema is sent with every request (`response_mime_type="application/json"`,
  `response_json_schema`), temperature 0; every answer is validated with a strict Pydantic model.
- An invalid answer is retried once; an API error (429, 5xx, network) is retried at most three times with a pause
  (5, 15, 30 s); otherwise `ExtractionStatus = failed` and the Gemini rules (R2, R5) skip the record. A wrong key or
  an unknown model (HTTP 400/401/403/404) stops the run with a message.
- Cache `output/llm_cache.json` (key = prompt version + model + text). Results: table `extractions` and `output/extractions.csv`.
- The prompt contains three examples written by us; none comes from `llm_dev_set.csv`.
- **Accuracy on `data/llm_dev_set.csv`** (`output/llm_dev_eval.csv`): `delay_days` 10/10, `partial_delivery` 10/10,
  `price_increase_pct` 10/10 (100 % each; the goal was 80 %). No prompt changes were needed after the first version.
- Check on the real data: all 60 extractions were compared with the message texts (templated sentences) by an
  independent script: 0 differences. 70 requests were needed for 61 distinct texts; the 9 extra were retries.
- Limitation: the dev texts and the real messages share the same style, so 100 % on 10 texts does not prove 100 % on new styles.

## 7. App and flows — TODO (Member 2)

Specification: `powerplatform/SPEC.md`. Fill in: screens (screenshots), F1, F2, F3 (trigger, steps, the feature that was new
for us, a screenshot of a successful run with the URL hidden).

## 8. Feedback loop

How it works (code is done; real data is TODO):
1. Both members review **every** case in the app by the guideline of `P03_stockbridge/BRIEF.md` section 10
   (about a third each): `ReviewDecision`, `ConfirmedCodes`, `ReviewerNotes`.
2. Export the list (Lists → Export → Export to CSV) and run
   `python main.py --scope team --import-reviews <file>`. Problems are printed (unknown CaseID, no decision, code not in the
   case, decision that does not fit the codes). `output/reviews.csv` is written; tables `reviews` and `review_codes` are loaded
   in every later run (a review of a case that no longer exists is skipped with a warning).
3. `output/rule_precision.csv` comes from the `-- PRECISION` query in `sql/queries.sql`.
4. The run prints and writes the R3 analysis: `output/r3_analysis.csv` and `output/r3_analysis.png` (gap in days of every
   R3 flag against the decision) and suggests a tolerance that removes every unconfirmed flag and keeps every confirmed one.
5. `python main.py --scope team --r3-tolerance <days>` writes `output/tuned/flags.csv`, `output/tuned/cases.csv` and
   `output/tuning_before_after.csv` (no new Gemini or API calls) and prints whether any confirmed flag was lost.

To fill in after the review: who reviewed how many cases; Confirmed / FalsePositive / NeedsMoreInfo counts; the precision
table; the chart; the chosen tolerance and why; the before/after table; how many fewer cases a reviewer has to look at;
which rules lost precision because of Gemini errors. **TODO.**

## 9. Extensions

Chosen (as required in the first week): **X4 Data-quality report** and **X6 Continuous integration**.

**X4 — data-quality report.** `python main.py --scope team --data-quality` writes `output/data_quality.html`: for every
column the type, empty values, distinct values, min/max or most frequent values; a chart for every numeric and date
column; the rejected rows by reason code; three observations computed from the data (rewrite them in our own words).
Checked: tests (`tests/test_data_quality.py`) on small data and on the real team file. Evidence: **TODO screenshot**.

**X6 — continuous integration.** `.github/workflows/ci.yml` runs `ruff check .` and `pytest` on every push and pull request;
no secret is needed (the tests use fakes). Evidence still to produce: the status badge above (replace OWNER/REPO),
and **one failing run and its fix** (for example: push a commit with an unused import, show the red run, push the fix,
show the green run; link or screenshot). **TODO.**

## 10. Known limitations

- Order values use the rate as the API returns it; no cross rates are computed.
- Q2 lists suppliers with at least one accepted proposal (all 6 have one).
- Possible improvements not implemented (they would change the counts against the reference): dates in the future,
  registration-style date checks.
- Gemini accuracy was measured on 10 short texts only.
- Further limitations: TODO.
