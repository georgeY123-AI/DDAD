"""Quick check of the Gemini setup: key, model name and one real request.

    python check_gemini.py [--model <name>]

Prints facts about the key (never the key itself) and makes ONE small request.
"""
import argparse
import sys

from src import extract


def main() -> int:
    parser = argparse.ArgumentParser(description="Check GEMINI_API_KEY and the model")
    parser.add_argument("--model", default=None)
    args = parser.parse_args()
    model = args.model or extract.default_model()

    info = extract.describe_key()
    print(f"key set: {info['set']}   length: {info['length']}   "
          f"starts like a Google key (AIza...): {info['starts_like_google_key']}")
    if info["had_quotes"]:
        print("Note: the variable contains quote characters. They are removed automatically here, "
              "but you can fix the variable too (no quotes around the key).")
    if not info["set"]:
        print("ERROR: GEMINI_API_KEY is not set. Set it, then open a NEW terminal.")
        return 1

    print(f"model: {model}")
    try:
        raw = extract.make_gemini_call(model)("Delivery delayed by 2 weeks. Prices remain unchanged.")
    except extract.GeminiFatalError as exc:
        print(f"ERROR: {exc}")
        names = extract.list_model_names()
        if names:
            print("Models your key can use (try one with --model):")
            print("  " + "\n  ".join(names))
        return 1
    except extract.GeminiRetryableError as exc:
        print(f"Temporary problem (try again in a minute): {exc}")
        return 1
    except extract.GeminiConfigError as exc:
        print(f"ERROR: {exc}")
        return 1

    parsed = extract.parse_answer(raw)
    if parsed is None:
        print(f"The model answered, but not in the expected format:\n{raw}")
        return 1
    print(f"OK. Answer: {parsed.model_dump()}")
    print("Expected: delay_days 14, partial_delivery False, price_increase_pct 0")
    return 0


if __name__ == "__main__":
    sys.exit(main())
