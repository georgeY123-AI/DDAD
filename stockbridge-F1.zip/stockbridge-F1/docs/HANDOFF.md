# Handoff: Member 1 (Python) → Member 2 (Power Platform)

Status: **HANDOFF_READY** — the Python side is finished and tested; your part can start.

## What this project is, in one paragraph
A webshop gets supplier answers to purchase proposals. Python checks the data, converts prices to forints, reads the supplier
messages with Gemini, applies five review rules and writes a list of risky proposals, `output/cases.csv`. **Your part is the
human side:** that list goes into SharePoint, a Power Apps app lets a reviewer decide, and flows send approvals (F2), a run
report (F1) and your own idea (F3). Details are in `powerplatform/SPEC.md`.

## What Member 1 did (all in this repository)
| Done | Where | Check it with |
|---|---|---|
| Validation of the CSV (6 of 66 rows rejected, with reason codes) | `src/validate.py`, `output/rejected_rows.csv` | `pytest` |
| Exchange rates from the Frankfurter API, cached | `src/api_client.py`, `output/api_cache/` | rerun: 0 API calls |
| SQLite database + SQL reports Q1–Q5 + precision query | `sql/`, `output/project.sqlite`, `output/sql/` | open the CSVs |
| Gemini extraction (structured output, retries, cache) + dev-set test (10/10) | `src/extract.py`, `output/extractions.csv` | `python check_gemini.py` (needs a key) |
| Rules R1–R5, `flags.csv`, `cases.csv` | `src/rules.py`, `output/cases.csv` | `pytest` |
| Review import, precision per rule, R3 tuning | `src/reviews.py`, `src/tuning.py` | `pytest` |
| Run-report sender for flow F1 (separate option) | `src/flow_client.py` | `pytest` |
| Extensions X4 (data-quality report) and X6 (CI) | `src/data_quality.py`, `.github/workflows/ci.yml` | `pytest`, `ruff check .` |

## Get it running (about 15 minutes)
1. Clone the repository. Install Python 3.11 or newer.
2. `python -m venv .venv`, activate it, `python -m pip install -r requirements.txt`.
3. `pytest` → all tests pass (no network and no key needed).
4. `python main.py --scope team` → prints the counts and the flags per rule.
   - The Frankfurter API needs no key. Gemini is **not** called if `output/llm_cache.json` is in the repository
     (Member 1 will commit it for you); otherwise you need your own `GEMINI_API_KEY`.

## What you use from Member 1's part
| You need | File / command |
|---|---|
| The list for SharePoint | `output/cases.csv` — columns: `CaseID, Severity, RiskScore, ReasonCodes, Status, ProductName, SupplierName, Currency, OrderValueHUF, delay_days` |
| The Excel workbook for F1 | `powerplatform/project_runs.xlsx` (copy of the course template; table `tblProjectRuns`) — upload a copy to OneDrive |
| The sender of the run report | `python main.py --scope team --send-report` (URL of your flow in the environment variable `FLOW_URL`) |
| Show a duplicate answer | `python main.py --scope team --resend-last-report` |
| Bring the review decisions back | export the list to CSV, then `python main.py --scope team --import-reviews <file>` |

The JSON of the run report, the receipt format and every column of the list are written down in `powerplatform/SPEC.md`.

## Your tasks, in order
1. **Now:** activate the developer plan (before 15 Nov) and check that you can save a flow with an HTTP trigger.
2. SharePoint list `P03 Review Queue` from `output/cases.csv` with the right column types.
3. Blank canvas app: browse, review (confirmed codes), approval state and gate, dashboard.
4. Flow F2 (approval), flow F1 (run report with duplicate check and error path), flow F3 (own idea, new feature).
5. Test F1 with the Python sender and keep the screenshots (hide the URL).
6. Together: review every case, export, import, precision, tuning (README section 8); fill README sections 7 and 8.

## How we work in Git
- `git pull` before you start, then `git add .`, `git commit -m "short message"`, `git push` when you finish.
- Member 1 works on branch `member1`, you on `member2`; merge into `main` with a pull request.
- Never commit keys, `.env` files or the flow URL. The CI workflow runs the tests on every push (no secrets needed).

## Documents we both fill
`README.md` (each part its own section, real results only), `AI_USAGE_LOG.md` (log your own AI use as it happens),
`CONTRIBUTIONS.md` (who did what and the cross-checks).

## Known issues and remaining tasks
- Nothing in the Python part is known to be broken. Real-world checks still open: the first real call of flow F1, and the real
  review data for the feedback loop.
- The numbers in README section 4 (flags per rule) are to be copied from the final run.
- Extension evidence (screenshots, badge, one failing and fixed CI run) is still to be produced.
