"""StockBridge review pipeline entry point.

    python main.py --scope team                       # the whole local pipeline (team scope = R1-R5)
    python main.py --scope team --import-reviews F    # + import the exported review decisions
    python main.py --scope team --r3-tolerance 0.5    # + tuned R3 run into output/tuned/
    python main.py --scope team --send-report         # + send the run report to flow F1
    python main.py --scope team --resend-last-report  # send the SAME report again (duplicate check)
    python main.py --scope team --data-quality        # + output/data_quality.html (extension X4)

Reads data/, writes output/. Answers of the API and of Gemini are cached, so reruns are fast and identical.
"""
import argparse
import csv
import json
import sqlite3
import sys
from pathlib import Path

import requests

from src import api_client, db, extract, flow_client, pricing, reports, reviews, rules, tuning, validate
from src.config import DATA_DIR, OUTPUT_DIR, RECORDS_FILE, SQL_DIR


def make_session():
    return requests.Session()


def write_rates_csv(path, rates) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["Currency", "RequestDate", "RateDate", "RateToHUF"])
        for r in sorted(rates, key=lambda r: (r.currency, r.request_date)):
            w.writerow([r.currency, r.request_date, r.rate_date, r.rate_to_huf])


def run(scope: str, session=None, call_factory=None, model=None, gemini_pause: float = 1.0, log=None,
        import_reviews=None, r3_tolerance=None) -> dict:
    model = model or extract.default_model()
    tolerance = tuning.parse_tolerance(r3_tolerance) if r3_tolerance is not None else None   # fail fast

    # 1. validation
    product_ids = validate.load_keys(DATA_DIR / "products.csv", "ProductID")
    supplier_ids = validate.load_keys(DATA_DIR / "suppliers.csv", "SupplierID")
    records = list(validate.read_records(DATA_DIR / RECORDS_FILE[scope]))
    accepted, rejected = validate.validate_records(records, product_ids, supplier_ids)
    validate.write_rejected_csv(OUTPUT_DIR / "rejected_rows.csv", rejected)

    # 2. exchange rates and order values
    pairs = api_client.needed_pairs(accepted)
    rates, live, cached = api_client.fetch_rates(
        pairs, OUTPUT_DIR / "api_cache", session or make_session())
    write_rates_csv(OUTPUT_DIR / "api_rates.csv", rates)
    rate_map = {(r.currency, r.request_date): r.rate_to_huf for r in rates}
    purchase_rows = [row for _, row in accepted]
    values = {row["PurchaseID"]: pricing.order_value_huf(row, rate_map) for row in purchase_rows}

    # 3. Gemini: the accepted messages and the 10 labelled dev texts (the client is created only if needed)
    dev_rows = db.read_csv_rows(DATA_DIR / "llm_dev_set.csv")
    texts = [row["SupplierMessage"] for row in purchase_rows] + [r["Text"] for r in dev_rows]
    factory = call_factory or (lambda: extract.make_gemini_call(model))
    gem = extract.extract_all(texts, OUTPUT_DIR / "llm_cache.json", factory, model, pause=gemini_pause, log=log)
    extraction_rows = extract.extraction_rows(purchase_rows, gem.results)
    extract.write_extractions_csv(OUTPUT_DIR / "extractions.csv", extraction_rows)
    dev_eval = extract.evaluate_dev(dev_rows, gem.results)
    extract.write_dev_eval_csv(OUTPUT_DIR / "llm_dev_eval.csv", dev_eval)
    accuracy = extract.accuracy_by_field(dev_eval)
    failed = sum(1 for e in extraction_rows if e["ExtractionStatus"] == "failed")

    # 4. rules, flags, cases
    products = db.read_csv_rows(DATA_DIR / "products.csv")
    suppliers = db.read_csv_rows(DATA_DIR / "suppliers.csv")
    inputs = rules.build_rule_inputs(purchase_rows, products, suppliers, values, extraction_rows)
    flags = rules.build_flags(inputs, scope)
    cases = rules.build_cases(flags, inputs)
    rules.write_flags_csv(OUTPUT_DIR / "flags.csv", flags)
    rules.write_cases_csv(OUTPUT_DIR / "cases.csv", cases)

    # 5. feedback loop (team): import the exported decisions; load reviews.csv whenever it exists
    review_problems = []
    if import_reviews:
        imported = reviews.import_reviews(Path(import_reviews), OUTPUT_DIR / "cases.csv")
        reviews.write_reviews_csv(OUTPUT_DIR / "reviews.csv", imported.rows)
        review_problems = imported.problems
    reviews_path = OUTPUT_DIR / "reviews.csv"
    review_rows = reviews.read_reviews_csv(reviews_path) if reviews_path.exists() else []

    # 6. database and SQL reports
    db_path = OUTPUT_DIR / "project.sqlite"
    warnings = db.build_database(db_path, products, suppliers, purchase_rows, rates, values,
                                 extraction_rows, flags, cases, review_rows)
    report_names = reports.run_reports(db_path, SQL_DIR / "queries.sql", OUTPUT_DIR / "sql")
    if reviews_path.exists():
        reports.run_named(db_path, SQL_DIR / "queries.sql", "PRECISION", OUTPUT_DIR / "rule_precision.csv")

    # 7. R3 analysis (when reviews exist) and the tuned run
    suggestion, tuned = None, None
    if review_rows:
        analysis = tuning.analysis_rows(inputs, review_rows)
        tuning.write_analysis_csv(OUTPUT_DIR / "r3_analysis.csv", analysis)
        suggestion = tuning.suggest_tolerance(analysis)
        if not tuning.plot_analysis(analysis, OUTPUT_DIR / "r3_analysis.png", tolerance):
            warnings.append("matplotlib is not installed: r3_analysis.png was not written")
    if tolerance is not None:
        flags_t = rules.build_flags(inputs, scope, tolerance)
        cases_t = rules.build_cases(flags_t, inputs)
        rules.write_flags_csv(OUTPUT_DIR / "tuned" / "flags.csv", flags_t)
        rules.write_cases_csv(OUTPUT_DIR / "tuned" / "cases.csv", cases_t)
        tuned = {"cases": len(cases_t), "flags": len(flags_t), "lost_confirmed": None}
        if review_rows:
            tuning.write_before_after_csv(
                OUTPUT_DIR / "tuning_before_after.csv",
                tuning.before_after_rows(flags, cases, flags_t, cases_t, review_rows, tolerance))
            tuned["lost_confirmed"] = tuning.lost_confirmed_flags(flags, flags_t, review_rows)
        else:
            warnings.append("no reviews.csv yet: tuning_before_after.csv was not written (import the reviews first)")

    return {"records": len(records), "accepted": len(accepted), "rejected": len(rejected),
            "rates": len(rates), "api_live": live, "api_cached": cached, "reports": report_names,
            "model": model, "extracted_ok": len(extraction_rows) - failed, "extraction_failed": failed,
            "gemini_requests": gem.requests, "gemini_cache_hits": gem.cache_hits, "dev_accuracy": accuracy,
            "flag_counts": {r: sum(1 for f in flags if f.rule_id == r) for r in rules.ACTIVE_RULES[scope]},
            "cases": len(cases), "high_cases": sum(1 for c in cases if c["Severity"] == "High"),
            "review_problems": review_problems, "warnings": warnings, "reviews_loaded": len(review_rows),
            "suggestion": suggestion, "tuned": tuned}


def send_and_save(report: dict, session=None) -> dict:
    receipt = flow_client.send_report(report, flow_client.get_flow_url(), session or make_session())
    flow_client.save_json(OUTPUT_DIR / "flow_receipt.json", receipt)
    return receipt


def print_receipt(receipt: dict) -> None:
    print(f"flow receipt: status={receipt['status']}  alert={str(receipt['alert']).lower()}  "
          f"(saved to output/flow_receipt.json)")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="StockBridge review pipeline")
    parser.add_argument("--scope", choices=["team", "solo"], default="team")
    parser.add_argument("--model", default=None, help="Gemini model (default: GEMINI_MODEL or %s)" % extract.DEFAULT_MODEL)
    parser.add_argument("--gemini-pause", type=float, default=1.0, help="seconds between live Gemini calls")
    parser.add_argument("--import-reviews", metavar="FILE", default=None,
                        help="exported SharePoint list (CSV) with the review decisions")
    parser.add_argument("--r3-tolerance", metavar="DAYS", default=None,
                        help="tuned R3 threshold in days (default behaviour = brief rule); writes output/tuned/")
    parser.add_argument("--send-report", action="store_true", help="send the run report to flow F1 (needs FLOW_URL)")
    parser.add_argument("--resend-last-report", action="store_true",
                        help="send output/last_report.json again (same run_id: the flow must answer 'duplicate')")
    parser.add_argument("--data-quality", action="store_true", help="also write output/data_quality.html (extension X4)")
    args = parser.parse_args(argv)
    try:
        if args.resend_last_report:
            path = OUTPUT_DIR / "last_report.json"
            if not path.exists():
                print("ERROR: there is no output/last_report.json yet. Run with --send-report first.", file=sys.stderr)
                return 1
            print_receipt(send_and_save(json.loads(path.read_text(encoding="utf-8"))))
            return 0
        s = run(args.scope, model=args.model, gemini_pause=args.gemini_pause,
                log=lambda message: print(message, flush=True), import_reviews=args.import_reviews,
                r3_tolerance=args.r3_tolerance)
    except FileNotFoundError as e:
        print(f"ERROR: missing input file: {e.filename}", file=sys.stderr)
        return 1
    except flow_client.FlowError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    except api_client.ApiError as e:
        print(f"ERROR: {e}\nThe run was stopped; no default rates are used.", file=sys.stderr)
        return 1
    except (extract.GeminiConfigError, extract.GeminiFatalError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    except (ValueError, sqlite3.Error) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1

    print(f"scope={args.scope}  rows={s['records']}  accepted={s['accepted']}  rejected={s['rejected']}")
    print(f"rates={s['rates']}  api_calls={s['api_live']}  from_cache={s['api_cached']}")
    print(f"gemini model={s['model']}  ok={s['extracted_ok']}  failed={s['extraction_failed']}  "
          f"requests={s['gemini_requests']}  from_cache={s['gemini_cache_hits']}")
    print("dev accuracy: " + "  ".join(
        f"{name} {ok}/{total} ({100 * ok // total}%)" for name, (ok, total) in s["dev_accuracy"].items()))
    low = [n for n, (ok, total) in s["dev_accuracy"].items() if ok * 100 < 80 * total]
    if low:
        print(f"WARNING: below 80% on: {', '.join(low)} - describe prompt changes in the README")
    if s["extraction_failed"]:
        print(f"WARNING: {s['extraction_failed']} record(s) have no valid extraction (status failed); "
              f"run again to retry them (answers already received are cached)")
    print("flags per rule: " + "  ".join(f"{r}={n}" for r, n in s["flag_counts"].items())
          + f"   cases={s['cases']} (High {s['high_cases']}, Medium {s['cases'] - s['high_cases']})")
    if args.import_reviews:
        print(f"reviews imported: {s['reviews_loaded']} cases, {len(s['review_problems'])} problem(s)")
        for problem in s["review_problems"]:
            print(f"  PROBLEM: {problem}")
    elif s["reviews_loaded"]:
        print(f"reviews loaded from output/reviews.csv: {s['reviews_loaded']}")
    if s["suggestion"]:
        print(f"R3 analysis: {s['suggestion'].message}")
    if s["tuned"]:
        t = s["tuned"]
        print(f"tuned run (R3 tolerance {args.r3_tolerance} days) -> output/tuned/: flags={t['flags']}  "
              f"cases={t['cases']} (before: {s['cases']})")
        if t["lost_confirmed"] is not None:
            print("confirmed R3 flags lost by tuning: " + (", ".join(t["lost_confirmed"]) if t["lost_confirmed"] else "none"))
    for warning in s["warnings"]:
        print(f"WARNING: {warning}")
    print(f"database=output/project.sqlite  reports={','.join(s['reports'])}")

    if args.data_quality:
        from src import data_quality
        path = data_quality.write_report(args.scope, DATA_DIR, OUTPUT_DIR)
        print(f"data quality report: {path}")
    if args.send_report:
        try:
            report = flow_client.build_report(args.scope, s["records"], s["accepted"], s["rejected"],
                                              s["cases"], s["high_cases"])
            flow_client.save_json(OUTPUT_DIR / "last_report.json", report)
            print_receipt(send_and_save(report))
        except flow_client.FlowError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
