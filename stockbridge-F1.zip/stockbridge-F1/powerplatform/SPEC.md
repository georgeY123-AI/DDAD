# Power Platform part: specification for Member 2

Everything here comes from `PROJECT_RULES.md` (sections 3.6, 3.7, 3.9) and `BRIEF.md` (sections 8, 9). If this file and
those documents differ, the course documents win. Python gives you `output/cases.csv` and the run-report sender.

## 0. Licence (do this first, before 15 November)
Activate the developer plan. Check that you can **save** a flow whose trigger is *When an HTTP request is received* (premium).
Tell the instructor if you cannot.

## 1. SharePoint list `P03 Review Queue`
Create it with **Create from CSV** (Week 6) from `output/cases.csv`, then set the column types in the import dialog:

| Column of `cases.csv` | Type in the list |
|---|---|
| `CaseID` | the `Title` column |
| `Severity` | Choice: High, Medium |
| `RiskScore` | Number, 1 decimal |
| `ReasonCodes` | Single line of text |
| `Status` | Choice: New, InReview, Resolved |
| `ProductName`, `SupplierName`, `Currency` | Single line of text |
| `OrderValueHUF`, `delay_days` | Number |

Then add the review columns:

| Column | Type | Values |
|---|---|---|
| `ReviewDecision` | Choice | Confirmed, FalsePositive, NeedsMoreInfo |
| `ReviewerNotes` | Multiple lines of text | |
| `ResolvedDate` | Date | set to today by **Resolve** |
| `ApprovalStatus` | Single line of text | written by flow F2 |
| `ApprovalComment` | Multiple lines of text | written by flow F2 |
| `ApprovalDate` | Date and time | written by flow F2 |
| `ConfirmedCodes` | Single line of text | reason codes the reviewer confirms, joined with `;` |

## 2. Canvas app (blank canvas app, not "Create an app from data")
- **Browse screen:** gallery of the cases with the key context columns, sorted by RiskScore (highest first), Severity filter,
  Status filter, CaseID search.
- **Review screen:** all context columns of the case, decision, notes, confirmed codes. Saving needs non-empty notes.
  **Start review** sets InReview. **Resolve** is allowed only for an InReview case with a decision that is not NeedsMoreInfo and with
  notes. A success or error message after every save.
  - Confirmed codes: combo box (multiple selection) with the items `Split(ThisItem.ReasonCodes, ";")`, saved with `Concat(...)`.
    Use the formula separators of your Power Apps language setting (Week 6).
  - Saving is refused if the decision does not fit the codes: `Confirmed` needs at least one confirmed code, `FalsePositive` none.
- **Approval:** show `ApprovalStatus` and `ApprovalComment` with a **Refresh** button and a **Request approval** button (F2).
  **Gate:** a High case can be resolved only when `ApprovalStatus` is `Approved`.
- **Dashboard screen:** at least three numbers or charts, for example cases by Severity, by Status, by ReasonCode.

## 3. Flows
**F1 run report (Python → flow).** Trigger *When an HTTP request is received*. Python sends exactly this JSON
(`python main.py --scope team --send-report`, URL in the environment variable `FLOW_URL`):
```json
{"run_id": "6f1d2c3e-8a4b-4c5d-9e6f-0a1b2c3d4e5f", "project_id": "P03", "scope": "team",
 "generated_at": "2026-12-01T10:15:00+01:00", "record_count": 66, "accepted_count": 60,
 "rejected_count": 6, "case_count": 31, "high_case_count": 17}
```
(illustrative values). The flow adds one row to the table `tblProjectRuns` of an Excel workbook in OneDrive
(upload a **copy** of `powerplatform/project_runs.xlsx`; the table already exists in it):

| Excel column | Value |
|---|---|
| `RunID`, `ProjectID`, `Scope` | `run_id`, `project_id`, `scope` |
| `ReceivedAt` | the time the **flow** received the report, Budapest time, `yyyy-MM-dd HH:mm:ss` (Week 11) |
| `RecordCount`, `AcceptedCount`, `RejectedCount`, `CaseCount`, `HighCaseCount` | the five counts |
| `Alert` | `Yes` or `No` |

and answers `{"run_id": "<same run_id>", "status": "recorded", "alert": true}` where `alert` is a JSON Boolean, `true` if
`high_case_count` > 0. It also sends an alert email to your university address when `alert` is true.
**Team additions:** the same `run_id` again → answer `"status": "duplicate"` and add no row
(test it with `python main.py --scope team --resend-last-report`); a Try/Catch error path answers **HTTP 500** and notifies you.
The Python client checks the receipt (same run_id, status `recorded` or `duplicate`, Boolean `alert`) and saves `output/flow_receipt.json`.

**F2 approval (Power Apps trigger, input = list item ID).** Answers the app at once:

| Case | Flow writes | Answer to the app |
|---|---|---|
| `Status` is Resolved, or `ApprovalStatus` already Pending or Approved | nothing | not accepted, with a message |
| `Severity` is Medium | `ApprovalStatus = NotRequired`, date | accepted, "no approval required" |
| `Severity` is High | `Pending`; after the approver (yourself) answered: `Approved` or `Rejected`, comment, date | accepted, "approval requested" — at once, before the approval |

**F3 your own flow** — must use at least one Power Automate feature that was **not** covered in class (not: manual, Forms,
Recurrence, RSS, Power Apps, HTTP, Approvals, Excel, Scopes). Idea from the brief: a Planner task for the buyer for every
Confirmed case, created by a SharePoint "item created or modified" trigger with a trigger condition. Document: purpose,
trigger, steps, the new feature, a screenshot of a successful run.

Messages and approvals go only to your own university address or your own Teams chat.

## 4. Feedback loop (together with Member 1)
Review **every** case in the app by the guideline in `BRIEF.md` section 10 (about a third each; *Modified By* shows who).
Then export the list (Lists → Export → Export to CSV) and give the file to Member 1 for `--import-reviews`.

## 5. What to deliver into the repository
`powerplatform/`: app export (`.msapp`) if available, flow screenshots (**hide the URL**), the Excel workbook with the rows
of your runs. README sections 7 and 8, `AI_USAGE_LOG.md` entries, `CONTRIBUTIONS.md`.
