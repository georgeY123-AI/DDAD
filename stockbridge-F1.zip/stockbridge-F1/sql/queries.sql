-- Q1
-- Purchase valuation: every accepted proposal with the rate used.
-- HUF has no row in api_rates, so LEFT JOIN + COALESCE gives RateDate = OrderDate and rate 1.
SELECT p.PurchaseID,
       pr.ProductName,
       s.SupplierName,
       p.Currency,
       COALESCE(a.RateDate, p.OrderDate) AS RateDate,
       COALESCE(a.RateToHUF, 1)          AS RateToHUF,
       v.OrderValueHUF
FROM purchases p
JOIN products     pr ON pr.ProductID  = p.ProductID
JOIN suppliers    s  ON s.SupplierID  = p.SupplierID
JOIN order_values v  ON v.PurchaseID  = p.PurchaseID
LEFT JOIN api_rates a ON a.Currency = p.Currency AND a.RequestDate = p.OrderDate
ORDER BY p.PurchaseID;

-- Q2
-- Spend by supplier: sum of the individually rounded order values.
SELECT s.SupplierName,
       COUNT(*)             AS ProposalCount,
       SUM(v.OrderValueHUF) AS TotalValueHUF
FROM purchases p
JOIN suppliers    s ON s.SupplierID = p.SupplierID
JOIN order_values v ON v.PurchaseID = p.PurchaseID
GROUP BY s.SupplierID, s.SupplierName
ORDER BY s.SupplierName;

-- Q3
-- Stock coverage exceptions (rule R3): stock runs out before delivery arrives.
-- Equality (StockOnHand * 7 = WeeklyDemand * LeadDays) is NOT an exception.
SELECT p.PurchaseID,
       pr.ProductName,
       p.StockOnHand,
       p.WeeklyDemand,
       s.LeadDays
FROM purchases p
JOIN products  pr ON pr.ProductID = p.ProductID
JOIN suppliers s  ON s.SupplierID = p.SupplierID
WHERE p.StockOnHand * 7 < p.WeeklyDemand * s.LeadDays
ORDER BY p.PurchaseID;

-- Q4
-- Review cases by category. A proposal counts once, even with several flags.
SELECT pr.Category,
       COUNT(*)                                                     AS ProposalCount,
       COUNT(c.CaseID)                                              AS CaseCount,
       COALESCE(SUM(CASE WHEN c.Severity = 'High' THEN 1 ELSE 0 END), 0) AS HighCaseCount
FROM purchases p
JOIN products pr ON pr.ProductID = p.ProductID
LEFT JOIN cases c ON c.CaseID = p.PurchaseID
GROUP BY pr.Category
ORDER BY pr.Category;

-- Q5
-- Product ranking by ordered quantity within each category (CTE + window function).
-- DENSE_RANK: equal totals share a rank and the next rank is not skipped.
WITH totals AS (
    SELECT pr.Category,
           pr.ProductName,
           SUM(p.Quantity) AS TotalQuantity
    FROM purchases p
    JOIN products pr ON pr.ProductID = p.ProductID
    GROUP BY pr.ProductID, pr.Category, pr.ProductName
)
SELECT Category,
       ProductName,
       TotalQuantity,
       DENSE_RANK() OVER (PARTITION BY Category ORDER BY TotalQuantity DESC) AS RankInCategory
FROM totals
ORDER BY Category, RankInCategory, ProductName;

-- PRECISION
-- Precision per rule (team, feedback loop). Reviewed = decision Confirmed or FalsePositive.
-- Confirmed = the flag's code is in the case's ConfirmedCodes. NeedsMoreInfo / no decision = Excluded.
WITH outcomes AS (
    SELECT f.RuleID, f.ReasonCode,
           CASE
               WHEN r.ReviewDecision IN ('Confirmed', 'FalsePositive') AND rc.ReasonCode IS NOT NULL THEN 'confirmed'
               WHEN r.ReviewDecision IN ('Confirmed', 'FalsePositive') THEN 'not_confirmed'
               ELSE 'excluded'
           END AS Outcome
    FROM flags f
    LEFT JOIN reviews r       ON r.CaseID = f.RecordID
    LEFT JOIN review_codes rc ON rc.CaseID = f.RecordID AND rc.ReasonCode = f.ReasonCode
),
counts AS (
    SELECT RuleID, ReasonCode,
           COUNT(*)                          AS Flags,
           SUM(Outcome = 'confirmed')        AS Confirmed,
           SUM(Outcome = 'not_confirmed')    AS NotConfirmed,
           SUM(Outcome = 'excluded')         AS Excluded
    FROM outcomes
    GROUP BY RuleID, ReasonCode
)
SELECT RuleID, ReasonCode, Flags, Confirmed, NotConfirmed, Excluded,
       CASE WHEN Confirmed + NotConfirmed = 0 THEN NULL
            ELSE ROUND(1.0 * Confirmed / (Confirmed + NotConfirmed), 2) END AS Precision
FROM counts
ORDER BY RuleID;
