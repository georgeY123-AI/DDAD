-- Schema of output/project.sqlite (rebuilt from scratch in every run).

CREATE TABLE products (
    ProductID   TEXT PRIMARY KEY,
    ProductName TEXT NOT NULL,
    Category    TEXT NOT NULL,
    TargetStock INTEGER NOT NULL,
    MaxOrderHUF INTEGER NOT NULL
);

CREATE TABLE suppliers (
    SupplierID        TEXT PRIMARY KEY,
    SupplierName      TEXT NOT NULL,
    Country           TEXT NOT NULL,
    PreferredCurrency TEXT NOT NULL,
    LeadDays          INTEGER NOT NULL
);

-- accepted records only
CREATE TABLE purchases (
    PurchaseID      TEXT PRIMARY KEY,
    ProductID       TEXT NOT NULL REFERENCES products(ProductID),
    SupplierID      TEXT NOT NULL REFERENCES suppliers(SupplierID),
    OrderDate       TEXT NOT NULL,
    Quantity        INTEGER NOT NULL,
    UnitPrice       REAL NOT NULL,
    Currency        TEXT NOT NULL,
    StockOnHand     INTEGER NOT NULL,
    WeeklyDemand    INTEGER NOT NULL,
    SupplierMessage TEXT
);

-- Gemini results, one row per accepted record (fields empty/NULL when ExtractionStatus = 'failed')
CREATE TABLE extractions (
    RecordID           TEXT PRIMARY KEY REFERENCES purchases(PurchaseID),
    delay_days         INTEGER,
    partial_delivery   TEXT CHECK (partial_delivery IN ('true', 'false')),
    price_increase_pct REAL,
    ExtractionStatus   TEXT NOT NULL CHECK (ExtractionStatus IN ('ok', 'failed'))
);

-- one row per (non-HUF currency, order date) taken from the Frankfurter API
CREATE TABLE api_rates (
    Currency    TEXT NOT NULL,
    RequestDate TEXT NOT NULL,
    RateDate    TEXT NOT NULL,
    RateToHUF   REAL NOT NULL,
    PRIMARY KEY (Currency, RequestDate)
);

-- value computed in Python with Decimal and rounded half up (BRIEF.md section 4)
CREATE TABLE order_values (
    PurchaseID    TEXT PRIMARY KEY REFERENCES purchases(PurchaseID),
    OrderValueHUF INTEGER NOT NULL
);

-- one row per matched rule and record
CREATE TABLE flags (
    RecordID   TEXT NOT NULL REFERENCES purchases(PurchaseID),
    RuleID     TEXT NOT NULL,
    ReasonCode TEXT NOT NULL,
    Severity   TEXT NOT NULL CHECK (Severity IN ('High', 'Medium')),
    RiskScore  REAL NOT NULL,
    PRIMARY KEY (RecordID, RuleID)
);

-- one row per record with at least one flag (same columns as output/cases.csv)
CREATE TABLE cases (
    CaseID        TEXT PRIMARY KEY REFERENCES purchases(PurchaseID),
    Severity      TEXT NOT NULL CHECK (Severity IN ('High', 'Medium')),
    RiskScore     REAL NOT NULL,
    ReasonCodes   TEXT NOT NULL,
    Status        TEXT NOT NULL,
    ProductName   TEXT,
    SupplierName  TEXT,
    Currency      TEXT,
    OrderValueHUF INTEGER,
    delay_days    INTEGER
);

-- team: reviewers' decisions, loaded from output/reviews.csv whenever that file exists
CREATE TABLE reviews (
    CaseID         TEXT PRIMARY KEY REFERENCES cases(CaseID),
    ReviewDecision TEXT CHECK (ReviewDecision IN ('Confirmed', 'FalsePositive', 'NeedsMoreInfo')),
    ConfirmedCodes TEXT,
    ReviewerNotes  TEXT
);

-- one row per confirmed reason code
CREATE TABLE review_codes (
    CaseID     TEXT NOT NULL REFERENCES cases(CaseID),
    ReasonCode TEXT NOT NULL,
    PRIMARY KEY (CaseID, ReasonCode)
);
