"""Frankfurter exchange-rate client (PROJECT_RULES.md 3.2, BRIEF.md section 4).

For every (Currency, OrderDate) pair of the accepted records, except HUF, one request:
    GET https://api.frankfurter.dev/v1/{OrderDate}?base={Currency}&symbols=HUF
For a weekend or holiday the API returns the last available rate and its actual date
(RateDate). The rate is used as returned; no cross rates are computed here.

Rules kept here:
  * explicit timeout on every request
  * a failed call stops the run with a clear message (ApiError); no default values
  * raw responses are cached in output/api_cache/, a rerun makes no new calls
  * HUF needs no call: its rate is 1 by definition (handled in SQL with COALESCE)
"""
import json
import re
import time
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

import requests

BASE_URL = "https://api.frankfurter.dev/v1"
TIMEOUT_SECONDS = 10
_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")


class ApiError(RuntimeError):
    """Raised when the rate service cannot give a valid rate. Stops the run."""


@dataclass(frozen=True)
class Rate:
    currency: str
    request_date: str
    rate_date: str
    rate_to_huf: Decimal


def cache_path(cache_dir: Path, currency: str, request_date: str) -> Path:
    return Path(cache_dir) / f"{currency}_{request_date}.json"


def needed_pairs(accepted_rows) -> list:
    """Sorted unique (Currency, OrderDate) pairs of the accepted rows, HUF excluded."""
    return sorted({(row["Currency"], row["OrderDate"])
                   for _, row in accepted_rows if row["Currency"] != "HUF"})


def parse_response(text: str, currency: str, request_date: str) -> Rate:
    """Check a raw API answer and turn it into a Rate. Raises ApiError if it is not usable."""
    where = f"{currency} on {request_date}"
    try:
        data = json.loads(text, parse_float=Decimal)
    except ValueError as exc:
        raise ApiError(f"Exchange-rate answer for {where} is not valid JSON.") from exc
    if not isinstance(data, dict):
        raise ApiError(f"Exchange-rate answer for {where} has an unexpected shape.")
    if data.get("base") != currency:
        raise ApiError(f"Exchange-rate answer for {where} has base {data.get('base')!r}, expected {currency!r}.")
    rate_date = data.get("date")
    if not isinstance(rate_date, str) or not _DATE.fullmatch(rate_date):
        raise ApiError(f"Exchange-rate answer for {where} has no valid date.")
    try:
        datetime.strptime(rate_date, "%Y-%m-%d")
    except ValueError as exc:
        raise ApiError(f"Exchange-rate answer for {where} has an impossible date {rate_date!r}.") from exc
    rates = data.get("rates")
    raw = rates.get("HUF") if isinstance(rates, dict) else None
    if raw is None or isinstance(raw, bool):
        raise ApiError(f"Exchange-rate answer for {where} contains no HUF rate.")
    try:
        rate = Decimal(str(raw))
    except InvalidOperation as exc:
        raise ApiError(f"Exchange-rate answer for {where} has a non-numeric HUF rate.") from exc
    if not rate.is_finite() or rate <= 0:
        raise ApiError(f"Exchange-rate answer for {where} has a non-positive HUF rate.")
    return Rate(currency, request_date, rate_date, rate)


def get_rate(currency: str, request_date: str, cache_dir: Path, session) -> tuple:
    """Return (Rate, from_cache). Reads the cache first; otherwise calls the API once."""
    path = cache_path(cache_dir, currency, request_date)
    if path.exists():
        try:
            return parse_response(path.read_text(encoding="utf-8"), currency, request_date), True
        except ApiError as exc:
            raise ApiError(f"Cache file {path} is unusable ({exc}) Delete it to fetch fresh data.") from exc

    url = f"{BASE_URL}/{request_date}"
    try:
        response = session.get(url, params={"base": currency, "symbols": "HUF"}, timeout=TIMEOUT_SECONDS)
    except requests.exceptions.Timeout as exc:
        raise ApiError(f"Exchange-rate request for {currency} on {request_date} timed out "
                       f"after {TIMEOUT_SECONDS} s. Check your connection and run again.") from exc
    except requests.exceptions.RequestException as exc:
        raise ApiError(f"Exchange-rate request for {currency} on {request_date} failed: {exc}") from exc
    if response.status_code != 200:
        raise ApiError(f"Exchange-rate request for {currency} on {request_date} returned "
                       f"HTTP {response.status_code}.")

    rate = parse_response(response.text, currency, request_date)   # parse BEFORE caching
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(response.text, encoding="utf-8")
    return rate, False


def fetch_rates(pairs, cache_dir: Path, session, pause: float = 0.2) -> tuple:
    """Fetch all pairs. Returns (list of Rate, live_calls, cache_hits). Stops at the first error."""
    rates, live, cached = [], 0, 0
    for currency, request_date in pairs:
        rate, from_cache = get_rate(currency, request_date, cache_dir, session)
        rates.append(rate)
        if from_cache:
            cached += 1
        else:
            live += 1
            time.sleep(pause)      # be polite to the free service
    return rates, live, cached
