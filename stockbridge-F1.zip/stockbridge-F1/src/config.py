"""Project-wide constants. No rule may depend on today's date."""
from datetime import date
from pathlib import Path

PROJECT_ID = "P03"
AS_OF_DATE = date(2026, 10, 30)  # fixed as-of date from PROJECT_RULES.md, NOT today's date

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "output"

RECORDS_FILE = {"team": "purchases_team.csv", "solo": "purchases_solo.csv"}

ALLOWED_CURRENCIES = {"EUR", "CZK", "PLN", "GBP", "USD", "HUF"}
SQL_DIR = ROOT / "sql"
