"""Data-quality report (extension X4): output/data_quality.html

Profiles the RAW records file (all rows, also the invalid ones): type, empty values, distinct values, min/max or
most frequent values for every column; a chart for every numeric and date column; the rejected rows by reason
code; three observations that are computed from the data (read them and rewrite them in your own words).
"""
import base64
import csv
import html
import io
import re
from collections import Counter
from datetime import datetime
from pathlib import Path

from .config import RECORDS_FILE

_INT = re.compile(r"-?\d+")
_NUM = re.compile(r"-?\d+(\.\d+)?")
_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")


def read_raw(path: Path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        return reader.fieldnames, [{k: (v or "").strip() for k, v in row.items()} for row in reader]


def _parse_date(text):
    try:
        return datetime.strptime(text, "%Y-%m-%d").date()
    except ValueError:
        return None


def column_type(values) -> str:
    filled = [v for v in values if v != ""]
    if not filled:
        return "empty"
    if all(_INT.fullmatch(v) for v in filled):
        return "integer"
    if all(_NUM.fullmatch(v) for v in filled):
        return "number"
    if all(_DATE.fullmatch(v) for v in filled):
        return "date"
    return "text"


def profile_column(name: str, values) -> dict:
    kind = column_type(values)
    filled = [v for v in values if v != ""]
    info = {"name": name, "type": kind, "rows": len(values), "empty": len(values) - len(filled),
            "distinct": len(set(filled)), "min": "", "max": "", "top": [], "numbers": [], "dates": []}
    if kind in ("integer", "number"):
        nums = [float(v) for v in filled]
        info.update(min=min(nums), max=max(nums), numbers=nums)
    elif kind == "date":
        dates = [d for d in (_parse_date(v) for v in filled) if d]
        if dates:
            info.update(min=min(dates).isoformat(), max=max(dates).isoformat(), dates=dates)
        info["unparseable"] = len(filled) - len(dates)
    if kind in ("text", "date") or not info["top"]:
        info["top"] = Counter(filled).most_common(5)
    return info


def observations(rows, rejected, masters=None) -> list:
    total = len(rows)
    by_reason = Counter(r["ReasonCode"] for r in rejected)
    reasons = ", ".join(f"{code} {n}" for code, n in sorted(by_reason.items()))
    obs = [f"{len(rejected)} of {total} rows ({100 * len(rejected) / total:.1f} %) are rejected by validation: "
           f"{reasons or 'none'}. Every other row passes all five checks."]
    dates = [_parse_date(r.get("OrderDate", "")) for r in rows]
    dates = [d for d in dates if d]
    weekend = sum(1 for d in dates if d.weekday() >= 5)
    obs.append(f"{weekend} of {len(dates)} readable order dates fall on a Saturday or Sunday, so the exchange-rate API "
               f"has to answer with the last working day's rate (RateDate differs from OrderDate).")
    currencies = Counter(r.get("Currency", "") for r in rows if r.get("Currency"))
    prices = [float(r["UnitPrice"]) for r in rows if _NUM.fullmatch(r.get("UnitPrice", ""))]
    non_huf = sum(n for c, n in currencies.items() if c != "HUF")
    obs.append(f"{non_huf} of {sum(currencies.values())} rows are not in HUF ({len(currencies)} currencies in total) and "
               f"UnitPrice ranges from {min(prices):g} to {max(prices):g}: prices are not comparable before conversion "
               f"to forints.")
    return obs


def _png_base64(fig) -> str:
    buffer = io.BytesIO()
    fig.savefig(buffer, format="png", dpi=110)
    return base64.b64encode(buffer.getvalue()).decode("ascii")


def _chart(info):
    """Base64 PNG of a numeric (histogram) or date (orders per week) column, or '' if matplotlib is missing."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return ""
    fig, ax = plt.subplots(figsize=(5.4, 2.6))
    if info["numbers"]:
        ax.hist(info["numbers"], bins=min(12, max(3, info["distinct"])), color="#2a9d8f")
        ax.set_ylabel("rows")
    else:
        weeks = Counter(d.isocalendar()[:2] for d in info["dates"])
        labels = sorted(weeks)
        ax.bar([f"{y}-W{w:02d}" for y, w in labels], [weeks[k] for k in labels], color="#e9c46a")
        ax.tick_params(axis="x", labelrotation=60, labelsize=7)
        ax.set_ylabel("rows per ISO week")
    ax.set_title(info["name"], fontsize=10)
    fig.tight_layout()
    data = _png_base64(fig)
    plt.close(fig)
    return data


def _rejected_chart(counts: Counter):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return ""
    fig, ax = plt.subplots(figsize=(5.4, 2.4))
    names = sorted(counts)
    ax.barh(names, [counts[n] for n in names], color="#e76f51")
    ax.set_title("rejected rows by reason code", fontsize=10)
    fig.tight_layout()
    data = _png_base64(fig)
    plt.close(fig)
    return data


def build_html(scope: str, header, rows, rejected) -> str:
    esc = html.escape
    profiles = [profile_column(name, [r[name] for r in rows]) for name in header]
    reasons = Counter(r["ReasonCode"] for r in rejected)
    parts = [f"<!doctype html><html lang='en'><head><meta charset='utf-8'><title>Data quality - {esc(RECORDS_FILE[scope])}</title>",
             "<style>body{font:15px/1.5 system-ui,sans-serif;max-width:980px;margin:2rem auto;padding:0 1rem;color:#222}"
             "table{border-collapse:collapse;margin:.5rem 0 1.5rem}td,th{border:1px solid #ccc;padding:4px 8px;text-align:left;"
             "vertical-align:top}th{background:#f2f2f2}img{max-width:100%}.n{text-align:right}</style></head><body>",
             f"<h1>Data quality report</h1><p>File <b>{esc(RECORDS_FILE[scope])}</b>: {len(rows)} rows, {len(header)} columns "
             f"(raw data, before validation).</p>",
             "<h2>Observations</h2><ol>" + "".join(f"<li>{esc(o)}</li>" for o in observations(rows, rejected)) + "</ol>",
             "<h2>Columns</h2><table><tr><th>column</th><th>type</th><th>empty</th><th>distinct</th><th>min / max or most frequent</th></tr>"]
    for p in profiles:
        if p["type"] in ("integer", "number"):
            summary = f"{p['min']:g} / {p['max']:g}"
        elif p["type"] == "date":
            summary = f"{p['min']} / {p['max']}" + (f" ({p['unparseable']} not a real date)" if p.get("unparseable") else "")
        else:
            summary = "; ".join(f"{v[:40]} ({n})" for v, n in p["top"])
        parts.append(f"<tr><td>{esc(p['name'])}</td><td>{p['type']}</td><td class='n'>{p['empty']}</td>"
                     f"<td class='n'>{p['distinct']}</td><td>{esc(summary)}</td></tr>")
    parts.append("</table><h2>Charts</h2>")
    for p in profiles:
        if p["numbers"] or p["dates"]:
            png = _chart(p)
            if png:
                parts.append(f"<img alt='{esc(p['name'])}' src='data:image/png;base64,{png}'>")
    parts.append("<h2>Rejected rows by reason code</h2><table><tr><th>reason code</th><th>rows</th></tr>")
    parts += [f"<tr><td>{esc(code)}</td><td class='n'>{n}</td></tr>" for code, n in sorted(reasons.items())]
    parts.append("</table>")
    if reasons:
        png = _rejected_chart(reasons)
        if png:
            parts.append(f"<img alt='rejected rows by reason code' src='data:image/png;base64,{png}'>")
    parts.append("<p><small>The observations are computed from the data by code; read and rewrite them in your own words.</small></p></body></html>")
    return "\n".join(parts)


def read_rejected(path: Path) -> list:
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_report(scope: str, data_dir: Path, output_dir: Path) -> Path:
    header, rows = read_raw(Path(data_dir) / RECORDS_FILE[scope])
    rejected = read_rejected(Path(output_dir) / "rejected_rows.csv")
    out = Path(output_dir) / "data_quality.html"
    out.write_text(build_html(scope, header, rows, rejected), encoding="utf-8")
    return out
