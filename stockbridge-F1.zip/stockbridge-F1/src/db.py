"""SQLite database: rebuilt from scratch in every run, so a rerun never duplicates rows."""
import csv
import sqlite3
from pathlib import Path

from .config import SQL_DIR

_INT_COLUMNS = {
    "products": {"TargetStock", "MaxOrderHUF"},
    "suppliers": {"LeadDays"},
    "purchases": {"Quantity", "StockOnHand", "WeeklyDemand"},
}


def read_csv_rows(path: Path) -> list:
    with open(path, encoding="utf-8-sig", newline="") as f:
        return [{k.strip(): (v or "").strip() for k, v in row.items()} for row in csv.DictReader(f)]


def _insert(conn, table: str, columns: list, rows: list) -> None:
    ints = _INT_COLUMNS.get(table, set())
    placeholders = ",".join("?" for _ in columns)
    data = [tuple(int(r[c]) if c in ints else r[c] for c in columns) for r in rows]
    conn.executemany(f"INSERT INTO {table} ({','.join(columns)}) VALUES ({placeholders})", data)


def build_database(path: Path, products, suppliers, purchases, rates, values: dict, extractions=(),
                   flags=(), cases=(), reviews=()) -> list:
    """Rebuild the database. Returns warnings (reviews of cases that no longer exist are skipped)."""
    warnings = []
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path.unlink()
    conn = sqlite3.connect(path)
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript((SQL_DIR / "schema.sql").read_text(encoding="utf-8"))
        _insert(conn, "products", ["ProductID", "ProductName", "Category", "TargetStock", "MaxOrderHUF"], products)
        _insert(conn, "suppliers", ["SupplierID", "SupplierName", "Country", "PreferredCurrency", "LeadDays"], suppliers)
        cols = ["PurchaseID", "ProductID", "SupplierID", "OrderDate", "Quantity", "UnitPrice",
                "Currency", "StockOnHand", "WeeklyDemand", "SupplierMessage"]
        conn.executemany(
            f"INSERT INTO purchases ({','.join(cols)}) VALUES ({','.join('?' for _ in cols)})",
            [(r["PurchaseID"], r["ProductID"], r["SupplierID"], r["OrderDate"], int(r["Quantity"]),
              float(r["UnitPrice"]), r["Currency"], int(r["StockOnHand"]), int(r["WeeklyDemand"]),
              r.get("SupplierMessage", "")) for r in purchases])
        conn.executemany(
            "INSERT INTO extractions (RecordID, delay_days, partial_delivery, price_increase_pct, ExtractionStatus) "
            "VALUES (?,?,?,?,?)",
            [(e["RecordID"],
              int(e["delay_days"]) if e["delay_days"] != "" else None,
              e["partial_delivery"] or None,
              float(e["price_increase_pct"]) if e["price_increase_pct"] != "" else None,
              e["ExtractionStatus"]) for e in extractions])
        conn.executemany(
            "INSERT INTO api_rates (Currency, RequestDate, RateDate, RateToHUF) VALUES (?,?,?,?)",
            [(r.currency, r.request_date, r.rate_date, float(r.rate_to_huf)) for r in rates])
        conn.executemany("INSERT INTO order_values (PurchaseID, OrderValueHUF) VALUES (?,?)",
                         sorted(values.items()))
        conn.executemany(
            "INSERT INTO flags (RecordID, RuleID, ReasonCode, Severity, RiskScore) VALUES (?,?,?,?,?)",
            [(f.record_id, f.rule_id, f.reason_code, f.severity, f.risk_score) for f in flags])
        case_cols = ["CaseID", "Severity", "RiskScore", "ReasonCodes", "Status", "ProductName",
                     "SupplierName", "Currency", "OrderValueHUF", "delay_days"]
        conn.executemany(
            f"INSERT INTO cases ({','.join(case_cols)}) VALUES ({','.join('?' for _ in case_cols)})",
            [tuple(None if c["delay_days"] == "" and k == "delay_days" else c[k] for k in case_cols) for c in cases])
        case_ids = {c["CaseID"] for c in cases}
        for r in reviews:
            if r["CaseID"] not in case_ids:
                warnings.append(f"review of {r['CaseID']} skipped: the case no longer exists")
                continue
            conn.execute("INSERT INTO reviews (CaseID, ReviewDecision, ConfirmedCodes, ReviewerNotes) VALUES (?,?,?,?)",
                         (r["CaseID"], r["ReviewDecision"] or None, r["ConfirmedCodes"], r["ReviewerNotes"]))
            conn.executemany("INSERT INTO review_codes (CaseID, ReasonCode) VALUES (?,?)",
                             [(r["CaseID"], c) for c in sorted(set(
                                 x.strip() for x in r["ConfirmedCodes"].split(";") if x.strip()))])
        conn.commit()
        problems = conn.execute("PRAGMA foreign_key_check").fetchall()
        if problems:
            raise sqlite3.IntegrityError(f"Foreign key problems: {problems}")
    finally:
        conn.close()
    return warnings
