"""Gemini extraction of structured fields from the free-text SupplierMessage
(PROJECT_RULES.md 3.3, BRIEF.md section 5).

* structured output: the JSON schema is sent with every request (response_mime_type + response_json_schema)
* every answer is validated in Python (Pydantic, strict types, no extra fields)
* an answer that fails validation is retried ONCE
* an API error (HTTP 429, 5xx, network) is retried at most THREE times with a pause
* a record that still has no valid answer becomes ExtractionStatus = failed (its Gemini rules are skipped)
* answers are cached in output/llm_cache.json; a rerun makes no new calls
* the key is read from the environment variable GEMINI_API_KEY, never from code
"""
import csv
import hashlib
import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field, ValidationError

DEFAULT_MODEL = "gemini-3.1-flash-lite"     # model of Week 3; override with --model or GEMINI_MODEL
PROMPT_VERSION = "v1"                       # change it when the prompt changes: the cache key includes it
RETRY_PAUSES = (5, 15, 30)                  # seconds before API retry 1, 2, 3  (at most three retries)
REQUEST_TIMEOUT_MS = 30_000
FIELDS = ["delay_days", "partial_delivery", "price_increase_pct"]

SYSTEM_PROMPT = """You read short answers from a supplier about a purchase proposal and return JSON.
Fields:
- delay_days (integer): the announced delay of the delivery in days. 0 if no delay is mentioned
  (for example "no delay expected", "delivery on schedule", "goods ship on the agreed date").
  Convert weeks to days: 2 weeks = 14 days.
- partial_delivery (boolean): true if only part of the ordered quantity will be delivered
  (for example "only 40% of the quantity is available", "about half of the items are in stock",
  "we can only send part now, the rest follows later"). Otherwise false.
- price_increase_pct (number): the announced price increase in percent. 0 if prices stay unchanged
  or no increase is mentioned. A price decrease is not an increase: use 0.
Use only what the message says. Do not guess. Answer with the JSON object only.

Examples (not from any test set):
Message: "Thanks. Delivery will be 2 weeks late. Prices remain unchanged."
{"delay_days": 14, "partial_delivery": false, "price_increase_pct": 0}
Message: "We can ship on the agreed date, but only 30% of the ordered quantity. Price increase of 4% from next month."
{"delay_days": 0, "partial_delivery": true, "price_increase_pct": 4}
Message: "Everything is on schedule."
{"delay_days": 0, "partial_delivery": false, "price_increase_pct": 0}
"""

RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "delay_days": {"type": "integer", "description": "announced delay in days; 0 if none"},
        "partial_delivery": {"type": "boolean", "description": "true if only part of the quantity is delivered"},
        "price_increase_pct": {"type": "number", "description": "announced price increase in percent; 0 if none"},
    },
    "required": FIELDS,
    "additionalProperties": False,
}


class Extraction(BaseModel):
    """What Gemini must return: exactly these three fields with these types."""
    model_config = ConfigDict(extra="forbid", strict=True)
    delay_days: int = Field(ge=0)
    partial_delivery: bool
    price_increase_pct: float = Field(ge=0)


class GeminiConfigError(RuntimeError):
    """Key or package missing: the run cannot start."""


class GeminiFatalError(RuntimeError):
    """Gemini rejected the request in a way a retry cannot fix (bad key, unknown model, ...)."""


class GeminiRetryableError(RuntimeError):
    """Temporary problem (HTTP 429, 5xx, network)."""


def default_model() -> str:
    return os.getenv("GEMINI_MODEL") or DEFAULT_MODEL


# ---- the API key ---------------------------------------------------------------------------
def get_api_key() -> str:
    """GEMINI_API_KEY without surrounding spaces or quote characters.
    On Windows a key saved as "abc" (with the quotes) is a common mistake; the quotes are not part of the key."""
    key = (os.getenv("GEMINI_API_KEY") or "").strip()
    if len(key) >= 2 and key[0] == key[-1] and key[0] in "\"'":
        key = key[1:-1].strip()
    return key


def describe_key() -> dict:
    """Facts about the key that are safe to print (never the key itself)."""
    raw = (os.getenv("GEMINI_API_KEY") or "").strip()
    key = get_api_key()
    return {"set": bool(key), "length": len(key), "had_quotes": raw != key,
            "starts_like_google_key": key.startswith("AIza")}


def make_client():
    key = get_api_key()
    if not key:
        raise GeminiConfigError("GEMINI_API_KEY is not set. Set the environment variable "
                                "(never put the key in code) and open a NEW terminal.")
    from google import genai
    from google.genai import types
    for name in ("google_genai", "google_genai.models"):   # hide the harmless AFC notice of the SDK
        logging.getLogger(name).setLevel(logging.ERROR)
    return genai.Client(api_key=key, http_options=types.HttpOptions(timeout=REQUEST_TIMEOUT_MS))


def list_model_names(limit: int = 20) -> list:
    """Names of Gemini models the key can see (used only to help when the model name is wrong)."""
    try:
        names = [m.name.replace("models/", "") for m in make_client().models.list()
                 if "gemini" in m.name and "generateContent" in (getattr(m, "supported_actions", None) or ["generateContent"])]
    except Exception:
        return []
    return sorted(names)[:limit]


# ---- the Gemini call ---------------------------------------------------------------------
def make_gemini_call(model: str, client=None):
    """Return call(text) -> raw answer text. The client is created here, only when first needed."""
    from google.genai import errors, types  # imported lazily: tests and cached runs need no SDK setup

    if client is None:
        client = make_client()

    config = types.GenerateContentConfig(
        system_instruction=SYSTEM_PROMPT,
        temperature=0,
        response_mime_type="application/json",
        response_json_schema=RESPONSE_SCHEMA,       # structured output: the schema goes with the request
    )

    def call(text: str) -> str:
        try:
            response = client.models.generate_content(
                model=model, contents=f"Supplier message:\n{text}", config=config)
        except errors.APIError as exc:
            code = getattr(exc, "code", None)
            if code in (408, 429) or (isinstance(code, int) and code >= 500):
                raise GeminiRetryableError(f"HTTP {code}: {exc}") from exc
            raise GeminiFatalError(
                f"Gemini rejected the request (HTTP {code}): {exc}\n"
                f"Check GEMINI_API_KEY and the model name '{model}' (option --model).") from exc
        except Exception as exc:                      # network problems and similar
            raise GeminiRetryableError(f"{type(exc).__name__}: {exc}") from exc
        return getattr(response, "text", None) or ""
    return call


# ---- validation and one extraction ---------------------------------------------------------
def parse_answer(raw):
    """Validate a raw answer. Returns an Extraction or None."""
    if not raw:
        return None
    text = raw.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)      # tolerate a code fence
    try:
        return Extraction.model_validate_json(text)
    except ValidationError:
        return None


def extract_one(call, text, sleep, retry_pauses=RETRY_PAUSES, log=None):
    """Returns (Extraction or None, number of requests made)."""
    say = log or (lambda message: None)
    requests_made = 0
    for validation_try in range(2):                      # first answer + ONE retry if it is invalid
        raw = None
        for attempt in range(len(retry_pauses) + 1):     # first try + at most THREE API retries
            requests_made += 1
            try:
                raw = call(text)
                break
            except GeminiRetryableError as exc:
                if attempt == len(retry_pauses):
                    say(f"  giving up after {attempt} retries: {str(exc)[:100]}")
                    return None, requests_made
                say(f"  temporary error ({str(exc)[:80]}), waiting {retry_pauses[attempt]} s, "
                    f"retry {attempt + 1}/{len(retry_pauses)}")
                sleep(retry_pauses[attempt])
        parsed = parse_answer(raw)
        if parsed is not None:
            return parsed, requests_made
        if validation_try == 0:
            say("  invalid answer, asking once more")
    return None, requests_made


# ---- cache ------------------------------------------------------------------------------------
def cache_key(model: str, text: str) -> str:
    return hashlib.sha256(f"{PROMPT_VERSION}|{model}|{text}".encode("utf-8")).hexdigest()


def load_cache(path: Path) -> dict:
    path = Path(path)
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("not an object")
        return data
    except ValueError as exc:
        raise GeminiConfigError(f"Cache file {path} is unreadable ({exc}). Delete it to start fresh.") from exc


def save_cache(path: Path, cache: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(cache, indent=1, sort_keys=True), encoding="utf-8")
    tmp.replace(path)


@dataclass
class ExtractionRun:
    results: dict = field(default_factory=dict)      # text -> Extraction or None (failed)
    requests: int = 0
    cache_hits: int = 0

    @property
    def failed(self) -> int:
        return sum(1 for v in self.results.values() if v is None)


def extract_all(texts, cache_path, call_factory, model, sleep=None, pause=1.0,
                retry_pauses=RETRY_PAUSES, log=None):
    """Extract every distinct text. The Gemini client is created only if something is not cached.
    log: optional function that receives progress messages."""
    sleep = sleep or time.sleep
    say = log or (lambda message: None)
    cache = load_cache(cache_path)
    unique = list(dict.fromkeys(texts))                  # unique texts, original order

    def cached_answer(text):
        entry = cache.get(cache_key(model, text))
        if entry is None:
            return None
        try:
            return Extraction.model_validate(entry)
        except ValidationError:
            return None                                  # damaged cache entry: ask again

    pending = [t for t in unique if t.strip() and cached_answer(t) is None]
    say(f"Gemini: {len(unique)} distinct texts, {len(unique) - len(pending)} answered from cache, "
        f"{len(pending)} to ask." + (" This can take a few minutes; answers are saved as they arrive, "
                                     "so you can stop (Ctrl+C) and run again." if pending else ""))
    run, call, done = ExtractionRun(), None, 0
    for text in unique:
        if not text.strip():
            run.results[text] = None                     # nothing to read: failed, no call, no invented values
            continue
        hit = cached_answer(text)
        if hit is not None:
            run.results[text] = hit
            run.cache_hits += 1
            continue
        if call is None:
            call = call_factory()
        done += 1
        say(f"[{done}/{len(pending)}] asking Gemini...")
        result, made = extract_one(call, text, sleep, retry_pauses, log)
        run.requests += made
        run.results[text] = result
        say(f"[{done}/{len(pending)}] {'ok' if result is not None else 'FAILED (no valid answer)'}")
        if result is not None:
            cache[cache_key(model, text)] = result.model_dump()
            save_cache(cache_path, cache)                # saved after every answer: an interrupted run loses nothing
        sleep(pause)                                     # be gentle with the free tier
    return run


# ---- extractions table / CSV -----------------------------------------------------------------------
def fmt_number(value) -> str:
    return str(int(value)) if float(value) == int(value) else repr(float(value))


def extraction_rows(purchase_rows, results: dict) -> list:
    rows = []
    for row in purchase_rows:
        result = results.get(row["SupplierMessage"])
        if result is None:
            rows.append({"RecordID": row["PurchaseID"], "delay_days": "", "partial_delivery": "",
                         "price_increase_pct": "", "ExtractionStatus": "failed"})
        else:
            rows.append({"RecordID": row["PurchaseID"], "delay_days": str(result.delay_days),
                         "partial_delivery": "true" if result.partial_delivery else "false",
                         "price_increase_pct": fmt_number(result.price_increase_pct),
                         "ExtractionStatus": "ok"})
    return rows


def write_extractions_csv(path: Path, rows: list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    cols = ["RecordID", *FIELDS, "ExtractionStatus"]
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


# ---- evaluation on the labelled dev set ---------------------------------------------------------------
def _num(value) -> str:
    d = Decimal(str(value).strip())
    return format(d.normalize(), "f") if d != 0 else "0"


def normalise(field_name: str, value) -> str:
    """Comparable text form: booleans true/false, numbers numerically (7 = 7.0)."""
    if value is None or str(value).strip() == "":
        return ""
    if field_name == "partial_delivery":
        if isinstance(value, bool):
            return "true" if value else "false"
        return str(value).strip().lower()
    return _num(value)


def evaluate_dev(dev_rows, results: dict) -> list:
    out = []
    for row in dev_rows:
        result = results.get(row["Text"])
        for name in FIELDS:
            gold = normalise(name, row[f"gold_{name}"])
            predicted = "" if result is None else normalise(name, getattr(result, name))
            out.append({"DevID": row["DevID"], "Field": name, "Gold": gold, "Predicted": predicted,
                        "Correct": "true" if predicted != "" and predicted == gold else "false"})
    return out


def accuracy_by_field(eval_rows) -> dict:
    acc = {}
    for name in FIELDS:
        rows = [r for r in eval_rows if r["Field"] == name]
        acc[name] = (sum(r["Correct"] == "true" for r in rows), len(rows))
    return acc


def write_dev_eval_csv(path: Path, rows: list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["DevID", "Field", "Gold", "Predicted", "Correct"], lineterminator="\n")
        w.writeheader()
        w.writerows(rows)
