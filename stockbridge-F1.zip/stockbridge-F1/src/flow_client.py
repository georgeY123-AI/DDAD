"""Client of flow F1 (PROJECT_RULES.md 3.7): sends the run report to the HTTP-triggered flow.

Exactly ONE request, with a timeout, never retried automatically. Every failure (timeout, non-2xx answer,
invalid receipt) ends with a clear message, not a traceback. The flow URL is a secret: it is read from the
environment variable FLOW_URL and never printed, logged or put into an error message.
"""
import json
import os
import uuid
from datetime import datetime
from pathlib import Path

import requests

PROJECT_ID = "P03"
TIMEOUT_SECONDS = 30
KNOWN_STATUSES = {"recorded", "duplicate"}
REPORT_KEYS = ["run_id", "project_id", "scope", "generated_at", "record_count", "accepted_count",
               "rejected_count", "case_count", "high_case_count"]


class FlowError(RuntimeError):
    """The report could not be delivered or the receipt is not valid."""


def get_flow_url() -> str:
    url = (os.getenv("FLOW_URL") or "").strip()
    if len(url) >= 2 and url[0] == url[-1] and url[0] in "\"'":
        url = url[1:-1].strip()
    if not url:
        raise FlowError("FLOW_URL is not set. Set the environment variable to the HTTP URL of flow F1 "
                        "(never put it in code or Git) and open a NEW terminal.")
    return url


def build_report(scope: str, record_count: int, accepted_count: int, rejected_count: int,
                 case_count: int, high_case_count: int, now: datetime = None, run_id: str = None) -> dict:
    now = now or datetime.now().astimezone()
    return {"run_id": run_id or str(uuid.uuid4()), "project_id": PROJECT_ID, "scope": scope,
            "generated_at": now.isoformat(timespec="seconds"), "record_count": record_count,
            "accepted_count": accepted_count, "rejected_count": rejected_count,
            "case_count": case_count, "high_case_count": high_case_count}


def validate_receipt(text: str, run_id: str) -> dict:
    try:
        receipt = json.loads(text)
    except ValueError:
        raise FlowError("The flow answered, but the receipt is not valid JSON.") from None
    if not isinstance(receipt, dict):
        raise FlowError("The flow answered, but the receipt has an unexpected shape.")
    if receipt.get("run_id") != run_id:
        raise FlowError("The receipt belongs to a different run_id: the flow did not record this report.")
    if receipt.get("status") not in KNOWN_STATUSES:
        raise FlowError(f"The receipt has an unknown status: {receipt.get('status')!r}.")
    if not isinstance(receipt.get("alert"), bool):
        raise FlowError("The receipt field 'alert' is not a JSON Boolean (true/false).")
    return receipt


def send_report(report: dict, url: str, session=None) -> dict:
    """POST the report once and return the validated receipt."""
    session = session or requests.Session()
    try:
        response = session.post(url, json=report, timeout=TIMEOUT_SECONDS)
    except requests.exceptions.Timeout:
        raise FlowError(f"The flow did not answer within {TIMEOUT_SECONDS} s (timeout). "
                        "The report may or may not have been recorded; check the flow's run history.") from None
    except requests.exceptions.RequestException as exc:
        raise FlowError(f"The flow could not be reached ({type(exc).__name__}). Check your connection "
                        "and that the flow is turned on.") from None
    if not 200 <= response.status_code < 300:
        raise FlowError(f"The flow answered HTTP {response.status_code}; the report was not recorded "
                        "(see the run history of the flow).")
    return validate_receipt(response.text, report["run_id"])


def save_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
