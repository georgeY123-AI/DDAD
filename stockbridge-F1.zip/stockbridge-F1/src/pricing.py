"""Order value in forints (rule R1 input, Q1/Q2). Exact Decimal arithmetic, half-up rounding.
Python's round() rounds halves to even, so it must not be used here."""
from decimal import ROUND_HALF_UP, Decimal


def rate_for(currency: str, order_date: str, rate_map: dict) -> Decimal:
    if currency == "HUF":
        return Decimal(1)                      # HUF needs no API call
    try:
        return rate_map[(currency, order_date)]
    except KeyError:
        raise ValueError(f"No exchange rate for {currency} on {order_date}.") from None


def order_value_huf(row: dict, rate_map: dict) -> int:
    rate = rate_for(row["Currency"], row["OrderDate"], rate_map)
    value = Decimal(row["Quantity"]) * Decimal(row["UnitPrice"]) * rate
    return int(value.quantize(Decimal(1), rounding=ROUND_HALF_UP))
