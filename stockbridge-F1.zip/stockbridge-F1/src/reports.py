"""Runs the reports of sql/queries.sql. Each query starts after a marker line '-- Q1', '-- Q2', ..."""
import csv
import re
import sqlite3
from pathlib import Path

_MARKER = re.compile(r"^--\s*(Q\d+|PRECISION)\s*$")


def split_queries(text: str) -> dict:
    """Return {marker: sql text}. Text before the first marker is ignored."""
    queries, current = {}, None
    for line in text.splitlines():
        m = _MARKER.match(line.strip())
        if m:
            current = m.group(1)
            if current in queries:
                raise ValueError(f"Marker '-- {current}' appears twice in queries.sql")
            queries[current] = []
        elif current is not None:
            queries[current].append(line)
    return {name: "\n".join(lines).strip() for name, lines in queries.items()}


def run_query(conn, sql: str):
    cur = conn.execute(sql)
    return [d[0] for d in cur.description], cur.fetchall()


def write_csv(path: Path, header, rows) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(header)
        w.writerows([["" if v is None else v for v in row] for row in rows])


def run_reports(db_path: Path, queries_path: Path, out_dir: Path) -> list:
    """Run every marker named Q<number>; save output/sql/Qn.csv. Returns the names written."""
    queries = split_queries(Path(queries_path).read_text(encoding="utf-8"))
    names = sorted((n for n in queries if re.fullmatch(r"Q\d+", n)), key=lambda n: int(n[1:]))
    conn = sqlite3.connect(db_path)
    try:
        for name in names:
            header, rows = run_query(conn, queries[name])
            write_csv(Path(out_dir) / f"{name}.csv", header, rows)
    finally:
        conn.close()
    return names


def run_named(db_path: Path, queries_path: Path, name: str, out_path: Path) -> None:
    """Run one marker (for example PRECISION) and save its result as a CSV file."""
    queries = split_queries(Path(queries_path).read_text(encoding="utf-8"))
    conn = sqlite3.connect(db_path)
    try:
        header, rows = run_query(conn, queries[name])
    finally:
        conn.close()
    write_csv(Path(out_path), header, rows)
