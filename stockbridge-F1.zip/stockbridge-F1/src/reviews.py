"""Review decisions coming back from the app (PROJECT_RULES.md 3.9, steps 1-2).

The exported SharePoint list is imported with  --import-reviews <file>  and written to output/reviews.csv.
"""
import csv
import re
from dataclasses import dataclass, field
from pathlib import Path

DECISIONS = ["Confirmed", "FalsePositive", "NeedsMoreInfo"]
REVIEW_COLUMNS = ["CaseID", "ReviewDecision", "ConfirmedCodes", "ReviewerNotes"]


@dataclass
class ImportResult:
    rows: list = field(default_factory=list)
    problems: list = field(default_factory=list)


def split_codes(text: str) -> list:
    return [c.strip() for c in re.split(r"[;,]", text or "") if c.strip()]


def read_case_codes(cases_csv: Path) -> dict:
    """CaseID -> list of its reason codes (rule order), in the order of cases.csv."""
    with open(cases_csv, encoding="utf-8-sig", newline="") as f:
        return {r["CaseID"]: split_codes(r["ReasonCodes"]) for r in csv.DictReader(f)}


def read_export(path: Path) -> list:
    """Rows of the exported list as dicts. Finds the header row (it contains 'ReviewDecision'),
    accepts 'Title' or 'CaseID' for the case id, and ignores every other column."""
    with open(path, encoding="utf-8-sig", newline="") as f:
        raw = list(csv.reader(f))
    header_index = next((i for i, row in enumerate(raw)
                         if any(c.strip().lower() == "reviewdecision" for c in row)), None)
    if header_index is None:
        raise ValueError("The export has no 'ReviewDecision' column. Export the list "
                         "'P03 Review Queue' with the review columns.")
    header = [c.strip().lower() for c in raw[header_index]]

    def col(row, *names):
        for n in names:
            if n in header and header.index(n) < len(row):
                return row[header.index(n)].strip()
        return ""
    return [{"CaseID": col(r, "caseid", "title"), "ReviewDecision": col(r, "reviewdecision"),
             "ConfirmedCodes": col(r, "confirmedcodes"), "ReviewerNotes": col(r, "reviewernotes")}
            for r in raw[header_index + 1:] if any(c.strip() for c in r)]


def import_reviews(export_path: Path, cases_csv: Path) -> ImportResult:
    case_codes = read_case_codes(cases_csv)
    result, seen = ImportResult(), {}
    for row in read_export(export_path):
        cid = row["CaseID"]
        if cid not in case_codes:
            result.problems.append(f"CaseID '{cid}' is not in cases.csv (row skipped)")
            continue
        if cid in seen:
            result.problems.append(f"CaseID '{cid}' appears more than once in the export (last row used)")
        seen[cid] = row

    for cid, codes_of_case in case_codes.items():
        row = seen.get(cid)
        if row is None:
            result.problems.append(f"{cid}: has no row in the export (treated as no decision)")
            result.rows.append({"CaseID": cid, "ReviewDecision": "", "ConfirmedCodes": "", "ReviewerNotes": ""})
            continue
        decision = next((d for d in DECISIONS if d.lower() == row["ReviewDecision"].lower()), "")
        if row["ReviewDecision"] and not decision:
            result.problems.append(f"{cid}: unknown decision '{row['ReviewDecision']}'")
        if not decision:
            if not row["ReviewDecision"]:
                result.problems.append(f"{cid}: no decision")
        confirmed = split_codes(row["ConfirmedCodes"])
        unknown = [c for c in confirmed if c not in codes_of_case]
        for c in unknown:
            result.problems.append(f"{cid}: confirmed code '{c}' is not one of the case's reason codes")
        valid = [c for c in codes_of_case if c in confirmed]          # rule order, valid codes only
        if decision == "Confirmed" and not valid:
            result.problems.append(f"{cid}: decision Confirmed needs at least one confirmed code")
        if decision == "FalsePositive" and valid:
            result.problems.append(f"{cid}: decision FalsePositive must not have confirmed codes")
        result.rows.append({"CaseID": cid, "ReviewDecision": decision, "ConfirmedCodes": ";".join(valid),
                            "ReviewerNotes": row["ReviewerNotes"]})
    return result


def write_reviews_csv(path: Path, rows: list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=REVIEW_COLUMNS, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def read_reviews_csv(path: Path) -> list:
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))
