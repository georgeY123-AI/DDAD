"""Review rules R1-R5, flags and cases (BRIEF.md section 6, PROJECT_RULES.md 3.4).

A flag = one matched rule for one record. A case = one record with at least one flag.
Team version: R1-R5. Solo version: R1-R3.
"""
import csv
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path

RULES = {                       # RuleID -> (ReasonCode, Severity)
    "R1": ("OVER_PURCHASE_LIMIT", "High"),
    "R2": ("SUPPLY_RISK", "Medium"),
    "R3": ("STOCK_RUNS_OUT", "High"),
    "R4": ("UNEXPECTED_CURRENCY", "Medium"),
    "R5": ("PRICE_RISE_LARGE_ORDER", "Medium"),
}
ACTIVE_RULES = {"team": ["R1", "R2", "R3", "R4", "R5"], "solo": ["R1", "R2", "R3"]}
RISK_SCORE = {"High": 0.9, "Medium": 0.6}
CASE_COLUMNS = ["CaseID", "Severity", "RiskScore", "ReasonCodes", "Status",
                "ProductName", "SupplierName", "Currency", "OrderValueHUF", "delay_days"]


@dataclass
class RuleInput:
    """One accepted record with everything the rules and the case columns need."""
    record_id: str
    product_name: str
    supplier_name: str
    currency: str
    preferred_currency: str
    quantity: int
    stock: int
    demand: int
    lead_days: int
    max_order_huf: int
    order_value_huf: int
    extraction_ok: bool = False
    delay_days: int = None          # None when the extraction failed
    partial_delivery: bool = None
    price_increase_pct: float = None


@dataclass
class Flag:
    record_id: str
    rule_id: str
    reason_code: str
    severity: str
    risk_score: float


def to_fraction(value) -> Fraction:
    return Fraction(str(value))


def r3_gap_days(stock: int, demand: int, lead_days: int):
    """Days by which the stock runs out BEFORE the delivery arrives: LeadDays - StockOnHand*7/WeeklyDemand.
    None when there is no demand."""
    if demand == 0:
        return None
    return Fraction(lead_days) - Fraction(stock * 7, demand)


def r3_matches(inp: RuleInput, tolerance=0) -> bool:
    """R3 of the brief: StockOnHand*7 < WeeklyDemand*LeadDays (tolerance 0, equality is NOT flagged).
    With a tolerance (days) the rule only fires when the gap is larger than the tolerance:
        WeeklyDemand*LeadDays - StockOnHand*7 > tolerance * WeeklyDemand       (exact arithmetic)"""
    return inp.demand * inp.lead_days - inp.stock * 7 > to_fraction(tolerance) * inp.demand


def evaluate_rules(inp: RuleInput, scope: str = "team", r3_tolerance=0) -> list:
    """Return the Flags of one record, in rule order (R1 first)."""
    hits = {
        "R1": inp.order_value_huf > inp.max_order_huf,
        "R2": inp.extraction_ok and (inp.delay_days >= 7 or inp.partial_delivery),
        "R3": r3_matches(inp, r3_tolerance),
        "R4": inp.currency != inp.preferred_currency,
        "R5": inp.extraction_ok and inp.price_increase_pct >= 5 and inp.quantity >= 50,
    }
    flags = []
    for rule_id in ACTIVE_RULES[scope]:
        if hits[rule_id]:
            code, severity = RULES[rule_id]
            flags.append(Flag(inp.record_id, rule_id, code, severity, RISK_SCORE[severity]))
    return flags


def build_rule_inputs(purchase_rows, products, suppliers, values: dict, extraction_rows) -> list:
    prod = {p["ProductID"]: p for p in products}
    sup = {s["SupplierID"]: s for s in suppliers}
    ext = {e["RecordID"]: e for e in extraction_rows}
    inputs = []
    for row in purchase_rows:
        p, s, e = prod[row["ProductID"]], sup[row["SupplierID"]], ext[row["PurchaseID"]]
        ok = e["ExtractionStatus"] == "ok"
        inputs.append(RuleInput(
            record_id=row["PurchaseID"], product_name=p["ProductName"], supplier_name=s["SupplierName"],
            currency=row["Currency"], preferred_currency=s["PreferredCurrency"],
            quantity=int(row["Quantity"]), stock=int(row["StockOnHand"]), demand=int(row["WeeklyDemand"]),
            lead_days=int(s["LeadDays"]), max_order_huf=int(p["MaxOrderHUF"]),
            order_value_huf=values[row["PurchaseID"]], extraction_ok=ok,
            delay_days=int(e["delay_days"]) if ok else None,
            partial_delivery=(e["partial_delivery"] == "true") if ok else None,
            price_increase_pct=float(e["price_increase_pct"]) if ok else None))
    return inputs


def build_flags(inputs, scope: str = "team", r3_tolerance=0) -> list:
    flags = [f for inp in inputs for f in evaluate_rules(inp, scope, r3_tolerance)]
    return sorted(flags, key=lambda f: (f.record_id, f.rule_id))


def build_cases(flags, inputs) -> list:
    """One row per record with at least one flag; sorted by RiskScore (high first), then CaseID."""
    by_id = {i.record_id: i for i in inputs}
    grouped = {}
    for f in flags:
        grouped.setdefault(f.record_id, []).append(f)
    cases = []
    for record_id, fl in grouped.items():
        fl = sorted(fl, key=lambda f: f.rule_id)
        inp = by_id[record_id]
        cases.append({
            "CaseID": record_id,
            "Severity": "High" if any(f.severity == "High" for f in fl) else "Medium",
            "RiskScore": max(f.risk_score for f in fl),
            "ReasonCodes": ";".join(f.reason_code for f in fl),
            "Status": "New",
            "ProductName": inp.product_name, "SupplierName": inp.supplier_name,
            "Currency": inp.currency, "OrderValueHUF": inp.order_value_huf,
            "delay_days": "" if inp.delay_days is None else inp.delay_days,
        })
    return sorted(cases, key=lambda c: (-c["RiskScore"], c["CaseID"]))


def write_flags_csv(path: Path, flags) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["RecordID", "RuleID", "ReasonCode", "Severity", "RiskScore"])
        for fl in flags:
            w.writerow([fl.record_id, fl.rule_id, fl.reason_code, fl.severity, fl.risk_score])


def write_cases_csv(path: Path, cases) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CASE_COLUMNS, lineterminator="\n")
        w.writeheader()
        w.writerows(cases)
