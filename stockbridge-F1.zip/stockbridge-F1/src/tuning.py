"""Tuning of rule R3 with the reviewers' decisions (PROJECT_RULES.md 3.9, step 4).

The value behind R3 is the gap in days: LeadDays - StockOnHand*7/WeeklyDemand (how long BEFORE the delivery the
stock runs out). The brief's rule flags every gap > 0. The business tolerance of the guideline ignores small gaps.
"""
import csv
from dataclasses import dataclass
from decimal import ROUND_CEILING, ROUND_HALF_UP, Decimal
from fractions import Fraction
from pathlib import Path

from . import rules

TUNED_RULE = "R3"
TUNED_CODE = rules.RULES[TUNED_RULE][0]
REVIEWED = ("Confirmed", "FalsePositive")


def parse_tolerance(text) -> Fraction:
    try:
        value = Fraction(str(text).strip())
    except (ValueError, ZeroDivisionError):
        raise ValueError(f"'{text}' is not a number of days (example: 0.5)") from None
    if value < 0:
        raise ValueError("The R3 tolerance must not be negative.")
    return value


def format_days(value) -> str:
    f = Fraction(str(value)) if not isinstance(value, Fraction) else value
    return str(f.numerator) if f.denominator == 1 else format(Decimal(f.numerator) / Decimal(f.denominator), "f")


def setting_text(tolerance) -> str:
    return f"tolerance = {format_days(tolerance)} days"


def _confirmed(review, code=TUNED_CODE):
    """True / False for a reviewed case, None when the case is excluded (no decision or NeedsMoreInfo)."""
    if review is None or review["ReviewDecision"] not in REVIEWED:
        return None
    return code in [c.strip() for c in review["ConfirmedCodes"].split(";") if c.strip()]


def analysis_rows(inputs, review_rows) -> list:
    """One row per R3 flag of the BRIEF rule (tolerance 0), with the gap and the reviewers' outcome."""
    by_case = {r["CaseID"]: r for r in review_rows}
    out = []
    for i in inputs:
        if not rules.r3_matches(i, 0):
            continue
        review = by_case.get(i.record_id)
        confirmed = _confirmed(review)
        out.append({"CaseID": i.record_id, "StockOnHand": i.stock, "WeeklyDemand": i.demand, "LeadDays": i.lead_days,
                    "GapDays": round(float(rules.r3_gap_days(i.stock, i.demand, i.lead_days)), 3),
                    "ReviewDecision": review["ReviewDecision"] if review else "",
                    "Outcome": "excluded" if confirmed is None else ("confirmed" if confirmed else "not_confirmed")})
    return sorted(out, key=lambda r: (r["GapDays"], r["CaseID"]))


@dataclass
class Suggestion:
    tolerance: str          # days, or None when no threshold separates the flags
    max_not_confirmed: float
    min_confirmed: float
    message: str


def suggest_tolerance(rows) -> Suggestion:
    """A threshold that removes every NOT confirmed flag and keeps every confirmed one (gap > tolerance is flagged)."""
    not_conf = [Fraction(str(r["GapDays"])) for r in rows if r["Outcome"] == "not_confirmed"]
    conf = [Fraction(str(r["GapDays"])) for r in rows if r["Outcome"] == "confirmed"]
    if not not_conf:
        return Suggestion(None, None, float(min(conf)) if conf else None,
                          "No R3 flag was left unconfirmed: there is nothing to remove.")
    if not conf:
        return Suggestion(None, float(max(not_conf)), None,
                          "No R3 flag was confirmed: a threshold cannot be chosen from this data.")
    hi, lo = max(not_conf), min(conf)
    if hi >= lo:
        return Suggestion(None, float(hi), float(lo),
                          "Confirmed and unconfirmed flags overlap: no tolerance separates them.")
    mid = ((hi + lo) / 2)
    candidate = Decimal(mid.numerator) / Decimal(mid.denominator)
    candidate = candidate.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if not (hi <= Fraction(candidate) < lo):
        candidate = (Decimal(hi.numerator) / Decimal(hi.denominator)).quantize(Decimal("0.001"), rounding=ROUND_CEILING)
    return Suggestion(format(candidate, "f"), float(hi), float(lo),
                      f"All unconfirmed flags have a gap of at most {float(hi):.3f} days; all confirmed flags have "
                      f"at least {float(lo):.3f} days. Any tolerance from {float(hi):.3f} up to (not including) "
                      f"{float(lo):.3f} works; suggested: {format(candidate, 'f')}.")


def write_analysis_csv(path: Path, rows) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    cols = ["CaseID", "StockOnHand", "WeeklyDemand", "LeadDays", "GapDays", "ReviewDecision", "Outcome"]
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def plot_analysis(rows, path: Path, tolerance=None) -> bool:
    """PNG: gap (days) of every R3 flag against the reviewers' outcome. Returns False if matplotlib is missing."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return False
    fig, ax = plt.subplots(figsize=(8, 3.6))
    levels = {"confirmed": 2, "not_confirmed": 1, "excluded": 0}
    colors = {"confirmed": "#2a9d8f", "not_confirmed": "#e76f51", "excluded": "#888888"}
    for outcome, y in levels.items():
        xs = [r["GapDays"] for r in rows if r["Outcome"] == outcome]
        ax.scatter(xs, [y] * len(xs), s=70, color=colors[outcome], alpha=0.8, label=f"{outcome} ({len(xs)})")
    ax.axvline(0, color="#999999", linestyle=":", linewidth=1)
    if tolerance is not None:
        ax.axvline(float(Fraction(str(tolerance))), color="#264653", linestyle="--", label=f"tolerance {format_days(tolerance)} d")
    ax.set_yticks(list(levels.values()))
    ax.set_yticklabels(["excluded", "not confirmed", "confirmed"])
    ax.set_xlabel("days the stock runs out before the delivery (LeadDays - StockOnHand*7/WeeklyDemand)")
    ax.set_title("R3 STOCK_RUNS_OUT: gap in days vs. reviewers' decision")
    ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return True


def rule_metrics(flags, review_rows, rule_id=TUNED_RULE) -> dict:
    """RuleFlags, ConfirmedFlags, NotConfirmedFlags and Precision of one rule (same definitions as rule_precision.csv)."""
    by_case = {r["CaseID"]: r for r in review_rows}
    code = rules.RULES[rule_id][0]
    mine = [f for f in flags if f.rule_id == rule_id]
    states = [_confirmed(by_case.get(f.record_id), code) for f in mine]
    confirmed, not_confirmed = states.count(True), states.count(False)
    precision = ""
    if confirmed + not_confirmed:
        precision = float((Decimal(confirmed) / Decimal(confirmed + not_confirmed)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
    return {"RuleFlags": len(mine), "ConfirmedFlags": confirmed, "NotConfirmedFlags": not_confirmed, "Precision": precision}


def lost_confirmed_flags(flags_before, flags_after, review_rows, rule_id=TUNED_RULE) -> list:
    """Confirmed flags of the rule that exist before but not after tuning (must be empty)."""
    by_case = {r["CaseID"]: r for r in review_rows}
    code = rules.RULES[rule_id][0]
    after = {f.record_id for f in flags_after if f.rule_id == rule_id}
    return sorted(f.record_id for f in flags_before if f.rule_id == rule_id
                  and _confirmed(by_case.get(f.record_id), code) is True and f.record_id not in after)


def before_after_rows(flags_before, cases_before, flags_after, cases_after, review_rows, tolerance_after) -> list:
    rows = []
    for version, flags, cases, tolerance in (("before", flags_before, cases_before, 0),
                                             ("after", flags_after, cases_after, tolerance_after)):
        rows.append({"Version": version, "RuleID": TUNED_RULE, "Setting": setting_text(tolerance),
                     **rule_metrics(flags, review_rows), "TotalCases": len(cases)})
    return rows


def write_before_after_csv(path: Path, rows) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    cols = ["Version", "RuleID", "Setting", "RuleFlags", "ConfirmedFlags", "NotConfirmedFlags", "Precision", "TotalCases"]
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)
