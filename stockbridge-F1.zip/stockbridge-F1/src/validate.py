"""Validation of the purchase records (PROJECT_RULES.md section 3.1).

Checks run in a fixed order; the FIRST failed check decides the reason code:
  1 MISSING_ID  2 DUPLICATE_ID  3 UNKNOWN_REFERENCE  4 INVALID_DATE  5 INVALID_VALUE
No other checks are added on purpose (no future-date check, etc.).
"""
import csv
import re
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from .config import ALLOWED_CURRENCIES

ID_COLUMN = "PurchaseID"
_INT = re.compile(r"\d+")
_DECIMAL = re.compile(r"\d+(\.\d+)?")   # decimal POINT only; a comma never matches
_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")


@dataclass
class Rejected:
    source_row: int      # line number in the CSV file, header = line 1
    record_id: str
    reason_code: str


def load_keys(path: Path, key_column: str) -> set:
    with open(path, encoding="utf-8-sig", newline="") as f:
        return {(r[key_column] or "").strip() for r in csv.DictReader(f)}


def read_records(path: Path):
    """Yield (source_row, row_dict) with all values stripped.
    source_row is the file line where the record starts (header = line 1)."""
    with open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        header = [h.strip() for h in next(reader)]
        prev_line = reader.line_num
        for values in reader:
            start_line = prev_line + 1
            prev_line = reader.line_num
            if not values:  # blank line
                continue
            row = {h: (values[i].strip() if i < len(values) else "") for i, h in enumerate(header)}
            yield start_line, row


def _is_real_date(text: str) -> bool:
    if not _DATE.fullmatch(text):
        return False
    try:
        datetime.strptime(text, "%Y-%m-%d")
    except ValueError:
        return False
    return True


def _int_in_range(text: str, low: int, high: int) -> bool:
    return bool(_INT.fullmatch(text)) and low <= int(text) <= high


def _values_ok(row: dict) -> bool:
    if not _int_in_range(row.get("Quantity", ""), 1, 10000):
        return False
    price = row.get("UnitPrice", "")
    if not _DECIMAL.fullmatch(price) or not (Decimal("0.01") <= Decimal(price) <= Decimal("1000000")):
        return False
    if row.get("Currency", "") not in ALLOWED_CURRENCIES:   # case-sensitive
        return False
    if not _int_in_range(row.get("StockOnHand", ""), 0, 100000):
        return False
    if not _int_in_range(row.get("WeeklyDemand", ""), 0, 100000):
        return False
    return True


def reason_for(row: dict, seen_ids: set, product_ids: set, supplier_ids: set):
    """Return the reason code of the first failed check, or None if the row is valid."""
    record_id = row.get(ID_COLUMN, "")
    if not record_id:
        return "MISSING_ID"
    if record_id in seen_ids:
        return "DUPLICATE_ID"
    if row.get("ProductID", "") not in product_ids or row.get("SupplierID", "") not in supplier_ids:
        return "UNKNOWN_REFERENCE"          # empty keys are not in the set either
    if not _is_real_date(row.get("OrderDate", "")):
        return "INVALID_DATE"
    if not _values_ok(row):
        return "INVALID_VALUE"
    return None


def validate_records(records, product_ids: set, supplier_ids: set):
    """records: iterable of (source_row, row_dict). Returns (accepted, rejected).
    accepted: list of (source_row, row_dict); rejected: list of Rejected."""
    accepted, rejected = [], []
    seen_ids = set()
    for source_row, row in records:
        code = reason_for(row, seen_ids, product_ids, supplier_ids)
        record_id = row.get(ID_COLUMN, "")
        if record_id:
            seen_ids.add(record_id)   # an ID counts as seen whether accepted or rejected
        if code:
            rejected.append(Rejected(source_row, record_id, code))
        else:
            accepted.append((source_row, row))
    return accepted, rejected


def write_rejected_csv(path: Path, rejected) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["SourceRow", "RecordID", "ReasonCode"])
        for r in rejected:
            w.writerow([r.source_row, r.record_id, r.reason_code])
