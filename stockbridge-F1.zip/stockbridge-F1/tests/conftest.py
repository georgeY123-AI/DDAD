import pytest


@pytest.fixture(autouse=True)
def no_real_sleep(monkeypatch):
    """The API client pauses between live calls; tests must not wait."""
    monkeypatch.setattr("src.api_client.time.sleep", lambda seconds: None)
