"""A rule-based stand-in for Gemini. It only exists so tests run without a network or a key."""
import json
import re


def fake_model_answer(text: str) -> str:
    delay = 0
    m = re.search(r"(\d+) days", text)
    if m:
        delay = int(m.group(1))
    m = re.search(r"(\d+) weeks", text)
    if m:
        delay = int(m.group(1)) * 7
    partial = bool(re.search(r"only part|half|Partial|Only \d+%", text))
    m = re.search(r"increase of (\d+(?:\.\d+)?)%", text)
    pct = float(m.group(1)) if m else 0
    return json.dumps({"delay_days": delay, "partial_delivery": partial, "price_increase_pct": pct})


class CountingCall:
    def __init__(self, answer=fake_model_answer):
        self.calls, self.answer = [], answer

    def __call__(self, text):
        self.calls.append(text)
        return self.answer(text)


def factory_for(call):
    return lambda: call
