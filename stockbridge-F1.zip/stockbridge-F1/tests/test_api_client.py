"""API client tests. They never call the real API: a fake session stands in for requests."""
import json
from decimal import Decimal

import pytest
import requests

import main
from src import api_client
from src.api_client import ApiError
from tests.fakes import CountingCall, factory_for


def body(base="EUR", date="2026-09-14", huf=400.5):
    return json.dumps({"amount": 1.0, "base": base, "date": date, "rates": {"HUF": huf}})


class FakeResponse:
    def __init__(self, text, status=200):
        self.text, self.status_code = text, status


class FakeSession:
    """Answers every request; remembers the calls it received."""
    def __init__(self, answer=None, error=None, rate_date_override=None):
        self.calls, self.answer, self.error, self.override = [], answer, error, rate_date_override

    def get(self, url, params=None, timeout=None):
        self.calls.append({"url": url, "params": params, "timeout": timeout})
        if self.error:
            raise self.error
        if self.answer is not None:
            return self.answer
        date = url.rsplit("/", 1)[1]
        return FakeResponse(body(params["base"], self.override or date))


# ---- request shape ---------------------------------------------------------
def test_request_url_params_and_timeout(tmp_path):
    s = FakeSession()
    api_client.get_rate("EUR", "2026-09-14", tmp_path, s)
    call, = s.calls
    assert call["url"] == "https://api.frankfurter.dev/v1/2026-09-14"
    assert call["params"] == {"base": "EUR", "symbols": "HUF"}
    assert call["timeout"] == api_client.TIMEOUT_SECONDS and call["timeout"] > 0


def test_rate_is_used_as_returned(tmp_path):
    s = FakeSession(FakeResponse(body(huf=395.12345)))
    rate, from_cache = api_client.get_rate("EUR", "2026-09-14", tmp_path, s)
    assert rate.rate_to_huf == Decimal("395.12345") and from_cache is False


def test_weekend_request_keeps_the_returned_rate_date(tmp_path):
    s = FakeSession(rate_date_override="2026-09-11")        # Saturday 2026-09-12 -> Friday
    rate, _ = api_client.get_rate("USD", "2026-09-12", tmp_path, s)
    assert (rate.request_date, rate.rate_date) == ("2026-09-12", "2026-09-11")


# ---- cache -----------------------------------------------------------------
def test_raw_response_is_cached_and_second_call_makes_no_request(tmp_path):
    s = FakeSession()
    api_client.get_rate("EUR", "2026-09-14", tmp_path, s)
    assert api_client.cache_path(tmp_path, "EUR", "2026-09-14").exists()
    rate, from_cache = api_client.get_rate("EUR", "2026-09-14", tmp_path, s)
    assert from_cache is True and len(s.calls) == 1


def test_invalid_answer_is_not_cached(tmp_path):
    with pytest.raises(ApiError):
        api_client.get_rate("EUR", "2026-09-14", tmp_path, FakeSession(FakeResponse("not json")))
    assert not api_client.cache_path(tmp_path, "EUR", "2026-09-14").exists()


def test_corrupt_cache_file_gives_a_clear_message(tmp_path):
    api_client.cache_path(tmp_path, "EUR", "2026-09-14").write_text("{broken", encoding="utf-8")
    with pytest.raises(ApiError, match="Delete it"):
        api_client.get_rate("EUR", "2026-09-14", tmp_path, FakeSession())


# ---- failures stop the run: no invented defaults ----------------------------
def test_timeout_gives_a_clear_error(tmp_path):
    with pytest.raises(ApiError, match="timed out"):
        api_client.get_rate("EUR", "2026-09-14", tmp_path, FakeSession(error=requests.exceptions.Timeout()))


def test_connection_error_gives_a_clear_error(tmp_path):
    with pytest.raises(ApiError, match="failed"):
        api_client.get_rate("EUR", "2026-09-14", tmp_path,
                            FakeSession(error=requests.exceptions.ConnectionError("no network")))


@pytest.mark.parametrize("status", [404, 429, 500])
def test_non_200_status(tmp_path, status):
    with pytest.raises(ApiError, match=f"HTTP {status}"):
        api_client.get_rate("EUR", "2026-09-14", tmp_path, FakeSession(FakeResponse("{}", status)))


@pytest.mark.parametrize("text", [
    "not json", "[]",
    json.dumps({"base": "USD", "date": "2026-09-14", "rates": {"HUF": 1}}),        # wrong base
    json.dumps({"base": "EUR", "date": "2026-09-14", "rates": {}}),                # no HUF
    json.dumps({"base": "EUR", "date": "2026-09-14", "rates": {"HUF": 0}}),        # zero rate
    json.dumps({"base": "EUR", "date": "2026-09-14", "rates": {"HUF": -3}}),       # negative
    json.dumps({"base": "EUR", "date": "2026-09-14", "rates": {"HUF": "abc"}}),    # not a number
    json.dumps({"base": "EUR", "date": "14.09.2026", "rates": {"HUF": 400}}),      # bad date
    json.dumps({"base": "EUR", "date": "2026-02-30", "rates": {"HUF": 400}}),      # impossible date
])
def test_unusable_answers_are_rejected(tmp_path, text):
    with pytest.raises(ApiError):
        api_client.get_rate("EUR", "2026-09-14", tmp_path, FakeSession(FakeResponse(text)))


def test_fetch_stops_at_first_failure(tmp_path):
    s = FakeSession(error=requests.exceptions.Timeout())
    with pytest.raises(ApiError):
        api_client.fetch_rates([("EUR", "2026-09-14"), ("USD", "2026-09-14")], tmp_path, s, pause=0)
    assert len(s.calls) == 1


# ---- which pairs are requested ---------------------------------------------
def test_needed_pairs_skip_huf_and_duplicates():
    rows = [(2, {"Currency": "HUF", "OrderDate": "2026-09-01"}),
            (3, {"Currency": "EUR", "OrderDate": "2026-09-01"}),
            (4, {"Currency": "EUR", "OrderDate": "2026-09-01"}),
            (5, {"Currency": "USD", "OrderDate": "2026-09-01"})]
    assert api_client.needed_pairs(rows) == [("EUR", "2026-09-01"), ("USD", "2026-09-01")]


# ---- the whole stage through main ------------------------------------------
@pytest.fixture
def out_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "OUTPUT_DIR", tmp_path)
    return tmp_path


def test_run_team_fetches_each_pair_once_and_rerun_uses_cache(out_dir):
    s1 = FakeSession()
    summary = main.run("team", session=s1, call_factory=factory_for(CountingCall()))
    assert summary["accepted"] == 60
    assert summary["rates"] == len(s1.calls) == summary["api_live"] > 0
    rows = (out_dir / "api_rates.csv").read_text(encoding="utf-8").splitlines()
    assert rows[0] == "Currency,RequestDate,RateDate,RateToHUF" and len(rows) == summary["rates"] + 1
    assert not any(r.startswith("HUF,") for r in rows)           # HUF is never stored
    s2 = FakeSession()
    again = main.run("team", session=s2, call_factory=factory_for(CountingCall()))
    assert s2.calls == [] and again["api_cached"] == again["rates"]


def test_main_prints_clear_message_and_returns_1_on_api_failure(out_dir, monkeypatch, capsys):
    monkeypatch.setattr(main, "make_session", lambda: FakeSession(error=requests.exceptions.Timeout()))
    assert main.main(["--scope", "team"]) == 1
    err = capsys.readouterr().err
    assert "timed out" in err and "no default rates" in err and "Traceback" not in err
