"""Data-quality report (extension X4)."""
import main
from src import data_quality as dq
from src.config import DATA_DIR
from tests.fakes import CountingCall, factory_for
from tests.test_api_client import FakeSession


def test_column_types():
    assert dq.column_type(["1", "-3", ""]) == "integer"
    assert dq.column_type(["1.5", "2"]) == "number"
    assert dq.column_type(["2026-09-01", "2026-02-30"]) == "date"
    assert dq.column_type(["abc", "1"]) == "text"
    assert dq.column_type(["", ""]) == "empty"


def test_profile_of_a_numeric_column():
    p = dq.profile_column("Quantity", ["5", "10", "", "5"])
    assert (p["type"], p["empty"], p["distinct"], p["min"], p["max"]) == ("integer", 1, 2, 5.0, 10.0)


def test_profile_of_a_date_column_counts_impossible_dates():
    p = dq.profile_column("OrderDate", ["2026-09-01", "2026-02-30", "2026-09-05"])
    assert p["min"] == "2026-09-01" and p["max"] == "2026-09-05" and p["unparseable"] == 1


def test_profile_of_a_text_column_lists_the_most_frequent_values():
    p = dq.profile_column("Currency", ["EUR", "EUR", "USD"])
    assert p["top"][0] == ("EUR", 2)


def test_report_on_the_real_team_file(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "OUTPUT_DIR", tmp_path)
    main.run("team", session=FakeSession(), call_factory=factory_for(CountingCall()), gemini_pause=0)
    path = dq.write_report("team", DATA_DIR, tmp_path)
    text = path.read_text(encoding="utf-8")
    assert path.name == "data_quality.html" and "66 rows, 10 columns" in text
    for column in ["PurchaseID", "OrderDate", "Quantity", "UnitPrice", "SupplierMessage"]:
        assert f"<td>{column}</td>" in text
    for code in ["MISSING_ID", "DUPLICATE_ID", "UNKNOWN_REFERENCE", "INVALID_DATE", "INVALID_VALUE"]:
        assert code in text
    assert text.count("<li>") == 3                                   # three observations
    assert text.count("data:image/png;base64") >= 5                  # charts of the numeric and date columns + rejected rows
    assert "6 of 66 rows" in text


def test_observations_are_computed_from_the_data():
    rows = [{"OrderDate": "2026-09-05", "Currency": "HUF", "UnitPrice": "10"},      # Saturday
            {"OrderDate": "2026-09-07", "Currency": "EUR", "UnitPrice": "2.5"}]
    obs = dq.observations(rows, [{"ReasonCode": "MISSING_ID"}])
    assert len(obs) == 3 and "1 of 2 rows (50.0 %)" in obs[0] and "1 of 2 readable order dates" in obs[1]
    assert "1 of 2 rows are not in HUF" in obs[2] and "2.5 to 10" in obs[2]
