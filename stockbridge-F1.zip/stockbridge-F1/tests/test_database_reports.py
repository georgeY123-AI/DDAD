"""Pricing, database and SQL report tests (tiny synthetic data; no network)."""
import csv
import sqlite3
from decimal import Decimal

import pytest

import main
from src import db, pricing, reports
from src.api_client import Rate
from src.config import SQL_DIR
from tests.fakes import CountingCall, factory_for
from tests.test_api_client import FakeSession

QUERIES = SQL_DIR / "queries.sql"

PRODUCTS = [
    {"ProductID": "P-1", "ProductName": "Alpha", "Category": "A", "TargetStock": "10", "MaxOrderHUF": "1000"},
    {"ProductID": "P-2", "ProductName": "Beta", "Category": "A", "TargetStock": "10", "MaxOrderHUF": "1000"},
    {"ProductID": "P-3", "ProductName": "Gamma", "Category": "A", "TargetStock": "10", "MaxOrderHUF": "1000"},
    {"ProductID": "P-4", "ProductName": "Delta", "Category": "B", "TargetStock": "10", "MaxOrderHUF": "1000"},
]
SUPPLIERS = [
    {"SupplierID": "SUP-1", "SupplierName": "Zeta Ltd", "Country": "DE", "PreferredCurrency": "EUR", "LeadDays": "10"},
    {"SupplierID": "SUP-2", "SupplierName": "Alef Kft", "Country": "HU", "PreferredCurrency": "HUF", "LeadDays": "3"},
]


def purchase(pid, product="P-1", supplier="SUP-1", date="2026-09-14", qty="1", price="1",
             cur="HUF", stock="100", demand="1"):
    return {"PurchaseID": pid, "ProductID": product, "SupplierID": supplier, "OrderDate": date,
            "Quantity": qty, "UnitPrice": price, "Currency": cur, "StockOnHand": stock,
            "WeeklyDemand": demand, "SupplierMessage": "msg"}


def build(tmp_path, purchases, rates=(), out="out"):
    rate_map = {(r.currency, r.request_date): r.rate_to_huf for r in rates}
    values = {p["PurchaseID"]: pricing.order_value_huf(p, rate_map) for p in purchases}
    path = tmp_path / "t.sqlite"
    db.build_database(path, PRODUCTS, SUPPLIERS, purchases, list(rates), values)
    names = reports.run_reports(path, QUERIES, tmp_path / out)
    return path, names


def read(tmp_path, name, out="out"):
    with open(tmp_path / out / f"{name}.csv", encoding="utf-8", newline="") as f:
        return list(csv.reader(f))


# ---- pricing: exact, half up -------------------------------------------------
@pytest.mark.parametrize("qty,price,rate,expected", [
    ("1", "2.5", "1", 3),            # half goes up (Python round() would give 2)
    ("1", "0.5", "1", 1),            # Python round(0.5) would give 0
    ("1", "1.4999", "1", 1),
    ("3", "1.5", "1", 5),            # 4.5 -> 5
    ("10", "12.5", "400.5", 50063),  # 50062.5 -> 50063
])
def test_order_value_rounds_half_up(qty, price, rate, expected):
    row = purchase("PO-1", qty=qty, price=price, cur="EUR")
    assert pricing.order_value_huf(row, {("EUR", "2026-09-14"): Decimal(rate)}) == expected


def test_huf_needs_no_rate():
    assert pricing.order_value_huf(purchase("PO-1", qty="3", price="1000"), {}) == 3000


def test_missing_rate_is_an_error_not_a_default():
    with pytest.raises(ValueError, match="No exchange rate"):
        pricing.order_value_huf(purchase("PO-1", cur="EUR"), {})


# ---- database ----------------------------------------------------------------
def test_tables_primary_keys_and_foreign_keys(tmp_path):
    path, _ = build(tmp_path, [purchase("PO-1")])
    conn = sqlite3.connect(path)
    def pk(t):
        return [c[1] for c in conn.execute(f"PRAGMA table_info({t})") if c[5]]
    assert pk("products") == ["ProductID"] and pk("suppliers") == ["SupplierID"]
    assert pk("purchases") == ["PurchaseID"] and pk("order_values") == ["PurchaseID"]
    assert sorted(pk("api_rates")) == ["Currency", "RequestDate"]
    fks = {(t, f[2]) for t in ("purchases", "order_values") for f in conn.execute(f"PRAGMA foreign_key_list({t})")}
    assert fks == {("purchases", "products"), ("purchases", "suppliers"), ("order_values", "purchases")}


def test_foreign_keys_are_enforced(tmp_path):
    with pytest.raises(sqlite3.IntegrityError):
        build(tmp_path, [purchase("PO-1", product="P-999")])


def test_rebuild_does_not_duplicate_rows(tmp_path):
    rows = [purchase("PO-1"), purchase("PO-2")]
    path, _ = build(tmp_path, rows)
    build(tmp_path, rows)
    conn = sqlite3.connect(path)
    assert conn.execute("SELECT COUNT(*) FROM purchases").fetchone()[0] == 2
    assert conn.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 4


# ---- report plumbing ---------------------------------------------------------
def test_split_queries_by_marker():
    text = "-- intro\nignored\n-- Q1\nSELECT 1;\n\n-- Q2\nSELECT 2;\n-- PRECISION\nSELECT 3;"
    assert reports.split_queries(text) == {"Q1": "SELECT 1;", "Q2": "SELECT 2;", "PRECISION": "SELECT 3;"}


def test_duplicate_marker_is_an_error():
    with pytest.raises(ValueError):
        reports.split_queries("-- Q1\nSELECT 1;\n-- Q1\nSELECT 2;")


def test_only_q_markers_are_written(tmp_path):
    _, names = build(tmp_path, [purchase("PO-1")])
    assert names == ["Q1", "Q2", "Q3", "Q4", "Q5"]


# ---- Q1 ------------------------------------------------------------------------
def test_q1_columns_rows_and_rates(tmp_path):
    rows = [purchase("PO-2", cur="USD", date="2026-09-12", qty="2", price="10"),   # Saturday
            purchase("PO-1", qty="3", price="100")]                                  # HUF
    rates = [Rate("USD", "2026-09-12", "2026-09-11", Decimal("300.5"))]
    build(tmp_path, rows, rates)
    q1 = read(tmp_path, "Q1")
    assert q1[0] == ["PurchaseID", "ProductName", "SupplierName", "Currency", "RateDate", "RateToHUF", "OrderValueHUF"]
    assert [r[0] for r in q1[1:]] == ["PO-1", "PO-2"]                                # sorted by PurchaseID
    assert q1[1][3:] == ["HUF", "2026-09-14", "1", "300"]                            # HUF: RateDate = OrderDate, rate 1
    assert q1[2][3:] == ["USD", "2026-09-11", "300.5", "6010"]                       # weekend: last ECB date shown


# ---- Q2 ------------------------------------------------------------------------
def test_q2_sums_individually_rounded_values(tmp_path):
    rows = [purchase("PO-1", price="2.5"), purchase("PO-2", price="2.5"),             # 2.5 -> 3 each
            purchase("PO-3", supplier="SUP-2", price="10")]
    build(tmp_path, rows)
    q2 = read(tmp_path, "Q2")
    assert q2[0] == ["SupplierName", "ProposalCount", "TotalValueHUF"]
    assert q2[1:] == [["Alef Kft", "1", "10"], ["Zeta Ltd", "2", "6"]]                 # 6, not round(5.0) = 5; sorted by name


# ---- Q3 (rule R3 boundary) ---------------------------------------------------------
def test_q3_equality_is_not_flagged_but_one_less_is(tmp_path):
    rows = [purchase("PO-1", stock="10", demand="7"),      # 70 = 7*10 -> equal, not flagged
            purchase("PO-2", stock="9", demand="7"),       # 63 < 70   -> flagged
            purchase("PO-3", stock="11", demand="7")]      # 77 > 70   -> not flagged
    build(tmp_path, rows)
    q3 = read(tmp_path, "Q3")
    assert q3[0] == ["PurchaseID", "ProductName", "StockOnHand", "WeeklyDemand", "LeadDays"]
    assert q3[1:] == [["PO-2", "Alpha", "9", "7", "10"]]


# ---- Q5 (window function) ----------------------------------------------------------
def test_q5_dense_rank_with_ties_and_sort_order(tmp_path):
    rows = [purchase("PO-1", product="P-1", qty="10"),
            purchase("PO-2", product="P-2", qty="10"),      # ties with Alpha -> both rank 1
            purchase("PO-3", product="P-3", qty="5"),       # next rank is 2, not 3
            purchase("PO-4", product="P-4", qty="1"),
            purchase("PO-5", product="P-1", qty="0".replace("0", "1"))]  # Alpha total 11
    build(tmp_path, rows)
    q5 = read(tmp_path, "Q5")
    assert q5[0] == ["Category", "ProductName", "TotalQuantity", "RankInCategory"]
    assert q5[1:] == [["A", "Alpha", "11", "1"], ["A", "Beta", "10", "2"], ["A", "Gamma", "5", "3"], ["B", "Delta", "1", "1"]]


def test_q5_ties_share_a_rank(tmp_path):
    rows = [purchase("PO-1", product="P-1", qty="10"), purchase("PO-2", product="P-2", qty="10"),
            purchase("PO-3", product="P-3", qty="5")]
    build(tmp_path, rows)
    q5 = read(tmp_path, "Q5")
    assert [(r[1], r[3]) for r in q5[1:4]] == [("Alpha", "1"), ("Beta", "1"), ("Gamma", "2")]


def test_q5_skips_products_without_proposals(tmp_path):
    build(tmp_path, [purchase("PO-1", product="P-1")])
    assert [r[1] for r in read(tmp_path, "Q5")[1:]] == ["Alpha"]


# ---- whole pipeline on the real data (fake rates) ------------------------------------
@pytest.fixture
def out_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "OUTPUT_DIR", tmp_path)
    return tmp_path


def test_team_run_builds_database_and_reports_and_is_repeatable(out_dir):
    s = FakeSession()
    first = main.run("team", session=s, call_factory=factory_for(CountingCall()))
    assert first["reports"] == ["Q1", "Q2", "Q3", "Q4", "Q5"]
    q1 = read(out_dir, "Q1", out="sql")
    assert len(q1) == 1 + 60                                   # one row per accepted proposal
    snapshot = {n: (out_dir / "sql" / f"{n}.csv").read_bytes() for n in first["reports"]}
    conn = sqlite3.connect(out_dir / "project.sqlite")
    counts = [conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("purchases", "order_values", "api_rates")]
    conn.close()
    assert counts == [60, 60, 45]
    main.run("team", session=FakeSession(), call_factory=factory_for(CountingCall()))                    # rerun from the cache
    assert {n: (out_dir / "sql" / f"{n}.csv").read_bytes() for n in first["reports"]} == snapshot
    conn = sqlite3.connect(out_dir / "project.sqlite")
    assert conn.execute("SELECT COUNT(*) FROM purchases").fetchone()[0] == 60
    assert conn.execute("PRAGMA foreign_key_check").fetchall() == []


def test_q2_total_equals_q1_total_on_real_data(out_dir):
    main.run("team", session=FakeSession(), call_factory=factory_for(CountingCall()))
    q1_total = sum(int(r[6]) for r in read(out_dir, "Q1", out="sql")[1:])
    q2_total = sum(int(r[2]) for r in read(out_dir, "Q2", out="sql")[1:])
    assert q1_total == q2_total
