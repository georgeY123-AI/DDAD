"""Gemini extraction tests. No test calls Gemini: fake call functions and a fake client stand in."""
import csv
import json
import sqlite3
from types import SimpleNamespace

import pytest
from google.genai import errors

import main
from src import extract
from src.extract import (
    Extraction,
    GeminiConfigError,
    GeminiFatalError,
    GeminiRetryableError,
    extract_all,
    extract_one,
    parse_answer,
)
from tests.fakes import CountingCall, factory_for, fake_model_answer
from tests.test_api_client import FakeSession

GOOD = json.dumps({"delay_days": 7, "partial_delivery": False, "price_increase_pct": 5})


def no_sleep(_):
    pass


# ---- validation of answers --------------------------------------------------------------
def test_valid_answer_is_parsed():
    r = parse_answer(GOOD)
    assert r == Extraction(delay_days=7, partial_delivery=False, price_increase_pct=5.0)


def test_code_fence_is_tolerated():
    assert parse_answer("```json\n" + GOOD + "\n```") is not None


@pytest.mark.parametrize("raw", [
    None, "", "not json", "[]",
    json.dumps({"delay_days": 7, "partial_delivery": False}),                                        # missing field
    json.dumps({"delay_days": 7, "partial_delivery": False, "price_increase_pct": 5, "x": 1}),        # extra field
    json.dumps({"delay_days": "7", "partial_delivery": False, "price_increase_pct": 5}),              # wrong type
    json.dumps({"delay_days": 7.5, "partial_delivery": False, "price_increase_pct": 5}),              # not an integer
    json.dumps({"delay_days": 7, "partial_delivery": "false", "price_increase_pct": 5}),              # string boolean
    json.dumps({"delay_days": -1, "partial_delivery": False, "price_increase_pct": 5}),               # negative
    json.dumps({"delay_days": 7, "partial_delivery": False, "price_increase_pct": -2}),
])
def test_invalid_answers_are_rejected(raw):
    assert parse_answer(raw) is None


def test_integer_price_increase_is_accepted_as_number():
    assert parse_answer(json.dumps({"delay_days": 0, "partial_delivery": True, "price_increase_pct": 8})).price_increase_pct == 8.0


# ---- retries ------------------------------------------------------------------------------------
def test_invalid_answer_is_retried_once_then_succeeds():
    answers = iter(["garbage", GOOD])
    calls = []
    result, made = extract_one(lambda t: (calls.append(t), next(answers))[1], "msg", no_sleep)
    assert result is not None and made == 2


def test_invalid_twice_means_failed_after_exactly_two_requests():
    calls = []
    result, made = extract_one(lambda t: (calls.append(t), "garbage")[1], "msg", no_sleep)
    assert result is None and made == 2 == len(calls)


def test_api_error_is_retried_at_most_three_times_with_pauses():
    pauses, calls = [], []

    def call(text):
        calls.append(text)
        raise GeminiRetryableError("HTTP 429")
    result, made = extract_one(call, "msg", pauses.append)
    assert result is None and made == 4 == len(calls)          # first try + three retries
    assert pauses == list(extract.RETRY_PAUSES) and len(pauses) == 3


def test_api_error_then_success():
    state = {"n": 0}

    def call(text):
        state["n"] += 1
        if state["n"] < 3:
            raise GeminiRetryableError("HTTP 503")
        return GOOD
    result, made = extract_one(call, "msg", no_sleep)
    assert result is not None and made == 3


# ---- the real call function: schema is sent, errors are mapped ----------------------------------------
class FakeClient:
    def __init__(self, reply=GOOD, error=None):
        self.seen, self.reply, self.error = [], reply, error
        self.models = self

    def generate_content(self, model, contents, config):
        self.seen.append({"model": model, "contents": contents, "config": config})
        if self.error:
            raise self.error
        return SimpleNamespace(text=self.reply)


def test_schema_and_json_mode_are_sent_with_the_request():
    client = FakeClient()
    assert extract.make_gemini_call("some-model", client=client)("Delivery delayed by 3 days.") == GOOD
    sent, = client.seen
    cfg = sent["config"]
    assert sent["model"] == "some-model" and "Delivery delayed by 3 days." in sent["contents"]
    assert cfg.response_mime_type == "application/json"
    assert cfg.response_json_schema == extract.RESPONSE_SCHEMA
    assert set(extract.RESPONSE_SCHEMA["properties"]) == set(extract.FIELDS)
    assert extract.RESPONSE_SCHEMA["additionalProperties"] is False
    assert cfg.temperature == 0


@pytest.mark.parametrize("code", [429, 500, 503])
def test_temporary_http_errors_are_retryable(code):
    err = errors.APIError(code, {"error": {"message": "x"}})
    with pytest.raises(GeminiRetryableError):
        extract.make_gemini_call("m", client=FakeClient(error=err))("t")


@pytest.mark.parametrize("code", [400, 401, 403, 404])
def test_permanent_http_errors_stop_the_run_with_a_clear_message(code):
    err = errors.APIError(code, {"error": {"message": "bad"}})
    with pytest.raises(GeminiFatalError, match="GEMINI_API_KEY"):
        extract.make_gemini_call("m", client=FakeClient(error=err))("t")


def test_network_errors_are_retryable():
    with pytest.raises(GeminiRetryableError):
        extract.make_gemini_call("m", client=FakeClient(error=ConnectionError("down")))("t")


def test_empty_response_counts_as_invalid_not_as_a_crash():
    assert extract.make_gemini_call("m", client=FakeClient(reply=None))("t") == ""


def test_missing_key_gives_a_clear_message(monkeypatch):
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    with pytest.raises(GeminiConfigError, match="GEMINI_API_KEY"):
        extract.make_gemini_call("m")


# ---- cache ----------------------------------------------------------------------------------------------
def test_answers_are_cached_and_rerun_makes_no_call_and_needs_no_key(tmp_path):
    call = CountingCall()
    cache = tmp_path / "llm_cache.json"
    first = extract_all(["Delay of 5 days.", "No delay expected."], cache, factory_for(call), "m", no_sleep, 0)
    assert first.requests == 2 and cache.exists()

    def must_not_be_called():
        raise AssertionError("client must not be created when everything is cached")
    second = extract_all(["Delay of 5 days.", "No delay expected."], cache, must_not_be_called, "m", no_sleep, 0)
    assert second.requests == 0 and second.cache_hits == 2
    assert second.results == first.results


def test_cache_key_depends_on_model_prompt_version_and_text(monkeypatch):
    k = extract.cache_key("m1", "text")
    assert k != extract.cache_key("m2", "text") and k != extract.cache_key("m1", "other")
    monkeypatch.setattr(extract, "PROMPT_VERSION", "v2")
    assert k != extract.cache_key("m1", "text")


def test_failed_records_are_not_cached_so_a_rerun_retries_them(tmp_path):
    cache = tmp_path / "c.json"
    run = extract_all(["x"], cache, factory_for(lambda t: "garbage"), "m", no_sleep, 0)
    assert run.failed == 1 and extract.load_cache(cache) == {}
    run = extract_all(["x"], cache, factory_for(lambda t: GOOD), "m", no_sleep, 0)
    assert run.failed == 0


def test_identical_texts_use_one_request(tmp_path):
    call = CountingCall()
    extract_all(["same", "same", "same"], tmp_path / "c.json", factory_for(call), "m", no_sleep, 0)
    assert call.calls == ["same"]


def test_empty_text_is_failed_without_a_call(tmp_path):
    call = CountingCall()
    run = extract_all(["  "], tmp_path / "c.json", factory_for(call), "m", no_sleep, 0)
    assert call.calls == [] and run.failed == 1


def test_corrupt_cache_gives_a_clear_message(tmp_path):
    path = tmp_path / "c.json"
    path.write_text("{broken", encoding="utf-8")
    with pytest.raises(GeminiConfigError, match="Delete it"):
        extract.load_cache(path)


# ---- evaluation on the dev set ---------------------------------------------------------------------------------
def test_normalisation_compares_numbers_numerically_and_booleans_as_text():
    assert extract.normalise("delay_days", "7") == extract.normalise("delay_days", 7.0) == "7"
    assert extract.normalise("price_increase_pct", "0") == extract.normalise("price_increase_pct", 0.0) == "0"
    assert extract.normalise("price_increase_pct", "8.50") == "8.5"
    assert extract.normalise("partial_delivery", True) == extract.normalise("partial_delivery", "TRUE") == "true"


def test_dev_evaluation_rows_and_accuracy():
    dev = [{"DevID": "D1", "Text": "a", "gold_delay_days": "3", "gold_partial_delivery": "true", "gold_price_increase_pct": "0"},
           {"DevID": "D2", "Text": "b", "gold_delay_days": "0", "gold_partial_delivery": "false", "gold_price_increase_pct": "5"}]
    results = {"a": Extraction(delay_days=3, partial_delivery=False, price_increase_pct=0.0), "b": None}
    rows = extract.evaluate_dev(dev, results)
    assert [(r["DevID"], r["Field"], r["Correct"]) for r in rows] == [
        ("D1", "delay_days", "true"), ("D1", "partial_delivery", "false"), ("D1", "price_increase_pct", "true"),
        ("D2", "delay_days", "false"), ("D2", "partial_delivery", "false"), ("D2", "price_increase_pct", "false")]
    assert rows[3]["Predicted"] == ""                                  # failed prediction is empty and wrong
    assert extract.accuracy_by_field(rows) == {"delay_days": (1, 2), "partial_delivery": (0, 2), "price_increase_pct": (1, 2)}


def test_fake_model_matches_the_real_dev_set_so_the_pipeline_plumbing_is_testable():
    from src import db
    from src.config import DATA_DIR
    dev = db.read_csv_rows(DATA_DIR / "llm_dev_set.csv")
    results = {r["Text"]: parse_answer(fake_model_answer(r["Text"])) for r in dev}
    acc = extract.accuracy_by_field(extract.evaluate_dev(dev, results))
    assert all(ok == total == 10 for ok, total in acc.values())


# ---- extractions CSV / table through the whole run ------------------------------------------------------------------
@pytest.fixture
def out_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "OUTPUT_DIR", tmp_path)
    return tmp_path


def test_run_writes_extractions_dev_eval_and_table(out_dir):
    s = main.run("team", session=FakeSession(), call_factory=factory_for(CountingCall()), gemini_pause=0)
    assert s["extracted_ok"] == 60 and s["extraction_failed"] == 0
    rows = list(csv.DictReader(open(out_dir / "extractions.csv", encoding="utf-8")))
    assert list(rows[0]) == ["RecordID", "delay_days", "partial_delivery", "price_increase_pct", "ExtractionStatus"]
    assert len(rows) == 60 and {r["ExtractionStatus"] for r in rows} == {"ok"}
    assert {r["partial_delivery"] for r in rows} <= {"true", "false"}
    ev = list(csv.DictReader(open(out_dir / "llm_dev_eval.csv", encoding="utf-8")))
    assert list(ev[0]) == ["DevID", "Field", "Gold", "Predicted", "Correct"] and len(ev) == 30
    conn = sqlite3.connect(out_dir / "project.sqlite")
    assert conn.execute("SELECT COUNT(*) FROM extractions").fetchone()[0] == 60
    assert conn.execute("PRAGMA foreign_key_check").fetchall() == []
    row = conn.execute("SELECT delay_days FROM extractions e JOIN purchases p ON p.PurchaseID=e.RecordID "
                       "WHERE p.SupplierMessage LIKE '%3 weeks%'").fetchone()
    assert row[0] == 21                                           # weeks are converted to days


def test_failed_records_are_reported_and_the_run_continues(out_dir):
    def flaky(text):
        if "backlog" in text:
            return "garbage"
        return fake_model_answer(text)
    s = main.run("team", session=FakeSession(), call_factory=factory_for(CountingCall(flaky)), gemini_pause=0)
    assert s["extraction_failed"] > 0 and s["extracted_ok"] + s["extraction_failed"] == 60
    rows = list(csv.DictReader(open(out_dir / "extractions.csv", encoding="utf-8")))
    failed = [r for r in rows if r["ExtractionStatus"] == "failed"]
    assert len(failed) == s["extraction_failed"]
    assert all(r["delay_days"] == r["partial_delivery"] == r["price_increase_pct"] == "" for r in failed)


def test_main_stops_with_a_clear_message_when_the_key_is_missing(out_dir, monkeypatch, capsys):
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.setattr(main, "make_session", lambda: FakeSession())
    assert main.main(["--scope", "team"]) == 1
    err = capsys.readouterr().err
    assert "GEMINI_API_KEY" in err and "Traceback" not in err


# ---- the key: quotes and spaces are not part of it ---------------------------------------------------
@pytest.mark.parametrize("saved,expected", [('"abc123"', "abc123"), ("'abc123'", "abc123"),
                                            ("  abc123  ", "abc123"), ('" abc123 "', "abc123"), ("abc123", "abc123")])
def test_key_quotes_and_spaces_are_removed(monkeypatch, saved, expected):
    monkeypatch.setenv("GEMINI_API_KEY", saved)
    assert extract.get_api_key() == expected


def test_describe_key_never_returns_the_key(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", '"AIzaSECRET"')
    info = extract.describe_key()
    assert info == {"set": True, "length": 10, "had_quotes": True, "starts_like_google_key": True}
    assert "SECRET" not in str(info)
    monkeypatch.delenv("GEMINI_API_KEY")
    assert extract.describe_key()["set"] is False


def test_client_receives_the_cleaned_key(monkeypatch):
    seen = {}
    monkeypatch.setenv("GEMINI_API_KEY", '"abc123"')
    monkeypatch.setattr("google.genai.Client", lambda api_key, http_options: seen.update(key=api_key) or object())
    extract.make_client()
    assert seen["key"] == "abc123"


# ---- progress messages ---------------------------------------------------------------------------------
def test_progress_messages_show_counts_and_each_answer(tmp_path):
    lines = []
    extract_all(["a 2 days", "b", "a 2 days"], tmp_path / "c.json", factory_for(CountingCall()), "m",
                no_sleep, 0, log=lines.append)
    assert lines[0].startswith("Gemini: 2 distinct texts, 0 answered from cache, 2 to ask.")
    assert "[1/2] asking Gemini..." in lines and "[2/2] ok" in lines


def test_progress_message_when_everything_is_cached(tmp_path):
    cache = tmp_path / "c.json"
    extract_all(["a"], cache, factory_for(CountingCall()), "m", no_sleep, 0)
    lines = []
    extract_all(["a"], cache, factory_for(CountingCall()), "m", no_sleep, 0, log=lines.append)
    assert lines == ["Gemini: 1 distinct texts, 1 answered from cache, 0 to ask."]


def test_retry_messages_tell_why_the_run_is_waiting():
    lines = []

    def call(text):
        raise GeminiRetryableError("HTTP 429 quota")
    extract_one(call, "msg", no_sleep, log=lines.append)
    assert sum("waiting" in line for line in lines) == 3 and "giving up" in lines[-1]


def test_sdk_notice_logger_is_silenced(monkeypatch):
    import logging
    monkeypatch.setenv("GEMINI_API_KEY", "abc")
    monkeypatch.setattr("google.genai.Client", lambda api_key, http_options: object())
    extract.make_client()
    assert logging.getLogger("google_genai.models").level == logging.ERROR
