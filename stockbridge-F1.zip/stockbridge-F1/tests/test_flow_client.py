"""Flow F1 client: exactly one request, timeout, clear errors, receipt checks, resend. No real flow is called."""
import json
import re
from datetime import datetime, timedelta, timezone

import pytest
import requests

import main
from src import flow_client
from src.flow_client import FlowError
from tests.fakes import CountingCall
from tests.test_api_client import FakeResponse, FakeSession

URL = "https://flow.example.invalid/secret-token-123"


class FlowSession:
    def __init__(self, status=200, body=None, error=None, duplicates=False):
        self.posts, self.status, self.body, self.error, self.duplicates, self.seen = [], status, body, error, duplicates, set()

    def post(self, url, json=None, timeout=None):
        self.posts.append({"url": url, "json": json, "timeout": timeout})
        if self.error:
            raise self.error
        run_id = json["run_id"]
        status = "duplicate" if run_id in self.seen else "recorded"
        self.seen.add(run_id)
        body = self.body if self.body is not None else {"run_id": run_id, "status": status, "alert": json["high_case_count"] > 0}
        return FakeResponse(body if isinstance(body, str) else __import__("json").dumps(body), self.status)

    get = FakeSession().get


def report(**over):
    r = flow_client.build_report("team", 66, 60, 6, 39, 24, now=datetime(2026, 12, 1, 10, 15, tzinfo=timezone(timedelta(hours=1))),
                                 run_id="6f1d2c3e-8a4b-4c5d-9e6f-0a1b2c3d4e5f")
    r.update(over)
    return r


# ---- the report -------------------------------------------------------------------------------------
def test_report_has_exactly_the_specified_keys_and_types():
    r = flow_client.build_report("team", 66, 60, 6, 39, 24)
    assert list(r) == flow_client.REPORT_KEYS
    assert re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}", r["run_id"])
    assert r["project_id"] == "P03" and r["scope"] == "team"
    assert re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}", r["generated_at"])
    assert all(isinstance(r[k], int) for k in flow_client.REPORT_KEYS[4:])


def test_every_run_gets_a_new_run_id():
    assert flow_client.build_report("team", 1, 1, 0, 0, 0)["run_id"] != flow_client.build_report("team", 1, 1, 0, 0, 0)["run_id"]


def test_generated_at_is_iso_with_utc_offset():
    assert report()["generated_at"] == "2026-12-01T10:15:00+01:00"


# ---- exactly one request, with a timeout ------------------------------------------------------------------
def test_one_request_with_timeout_and_json_body():
    s = FlowSession()
    receipt = flow_client.send_report(report(), URL, s)
    post, = s.posts
    assert post["url"] == URL and post["timeout"] == flow_client.TIMEOUT_SECONDS > 0 and post["json"] == report()
    assert receipt == {"run_id": report()["run_id"], "status": "recorded", "alert": True}


def test_alert_is_false_without_high_cases():
    assert flow_client.send_report(report(high_case_count=0), URL, FlowSession())["alert"] is False


@pytest.mark.parametrize("error,fragment", [(requests.exceptions.Timeout(), "timeout"),
                                            (requests.exceptions.ConnectionError(URL), "could not be reached")])
def test_network_failures_give_clear_messages_without_retry_and_without_the_url(error, fragment):
    s = FlowSession(error=error)
    with pytest.raises(FlowError, match=fragment) as exc:
        flow_client.send_report(report(), URL, s)
    assert len(s.posts) == 1 and "secret-token" not in str(exc.value)


@pytest.mark.parametrize("status", [400, 404, 500, 502])
def test_non_2xx_answer(status):
    s = FlowSession(status=status, body="{}")
    with pytest.raises(FlowError, match=f"HTTP {status}"):
        flow_client.send_report(report(), URL, s)
    assert len(s.posts) == 1


@pytest.mark.parametrize("body", [
    "not json", "[]", "{}",
    {"run_id": "other", "status": "recorded", "alert": True},                                      # different run
    {"run_id": "6f1d2c3e-8a4b-4c5d-9e6f-0a1b2c3d4e5f", "status": "weird", "alert": True},        # unknown status
    {"run_id": "6f1d2c3e-8a4b-4c5d-9e6f-0a1b2c3d4e5f", "status": "recorded", "alert": "true"},   # string, not Boolean
    {"run_id": "6f1d2c3e-8a4b-4c5d-9e6f-0a1b2c3d4e5f", "status": "recorded", "alert": 1},        # number, not Boolean
    {"run_id": "6f1d2c3e-8a4b-4c5d-9e6f-0a1b2c3d4e5f", "status": "recorded"},                    # no alert
])
def test_invalid_receipts_are_rejected(body):
    with pytest.raises(FlowError):
        flow_client.send_report(report(), URL, FlowSession(body=body))


def test_duplicate_status_is_a_valid_receipt():
    s = FlowSession()
    flow_client.send_report(report(), URL, s)
    assert flow_client.send_report(report(), URL, s)["status"] == "duplicate"


def test_flow_url_comes_from_the_environment(monkeypatch):
    monkeypatch.delenv("FLOW_URL", raising=False)
    with pytest.raises(FlowError, match="FLOW_URL"):
        flow_client.get_flow_url()
    monkeypatch.setenv("FLOW_URL", f'"{URL}"')
    assert flow_client.get_flow_url() == URL


# ---- through main: separate option, receipt file, resend, no URL in the output ------------------------------------------------
@pytest.fixture
def cli(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "OUTPUT_DIR", tmp_path)
    session = FlowSession()
    both = type("Both", (), {"get": FakeSession().get, "post": session.post})()
    monkeypatch.setattr(main, "make_session", lambda: both)
    monkeypatch.setattr(main.extract, "make_gemini_call", lambda model: CountingCall())
    monkeypatch.setenv("FLOW_URL", URL)
    return tmp_path, session


def test_normal_run_does_not_send_anything(cli):
    out, session = cli
    assert main.main(["--scope", "team", "--gemini-pause", "0"]) == 0
    assert session.posts == [] and not (out / "flow_receipt.json").exists()


def test_send_report_saves_receipt_and_last_report(cli, capsys):
    out, session = cli
    assert main.main(["--scope", "team", "--gemini-pause", "0", "--send-report"]) == 0
    post, = session.posts
    assert post["json"]["accepted_count"] == 60 and post["json"]["rejected_count"] == 6 and post["json"]["record_count"] == 66
    receipt = json.loads((out / "flow_receipt.json").read_text())
    assert receipt["status"] == "recorded" and receipt["run_id"] == post["json"]["run_id"]
    assert json.loads((out / "last_report.json").read_text()) == post["json"]
    assert "secret-token" not in capsys.readouterr().out


def test_resend_last_report_gets_duplicate(cli, capsys):
    out, session = cli
    main.main(["--scope", "team", "--gemini-pause", "0", "--send-report"])
    assert main.main(["--scope", "team", "--resend-last-report"]) == 0
    assert len(session.posts) == 2 and session.posts[0]["json"]["run_id"] == session.posts[1]["json"]["run_id"]
    assert json.loads((out / "flow_receipt.json").read_text())["status"] == "duplicate"
    assert "status=duplicate" in capsys.readouterr().out


def test_resend_without_a_previous_report_is_a_clear_error(cli, capsys):
    assert main.main(["--resend-last-report"]) == 1
    assert "last_report.json" in capsys.readouterr().err


def test_missing_flow_url_gives_a_message_not_a_traceback(cli, monkeypatch, capsys):
    monkeypatch.delenv("FLOW_URL")
    assert main.main(["--scope", "team", "--gemini-pause", "0", "--send-report"]) == 1
    err = capsys.readouterr().err
    assert "FLOW_URL" in err and "Traceback" not in err


def test_flow_failure_gives_a_message_not_a_traceback(cli, monkeypatch, capsys):
    out, _ = cli
    bad = FlowSession(status=500, body="{}")
    both = type("Both", (), {"get": FakeSession().get, "post": bad.post})()
    monkeypatch.setattr(main, "make_session", lambda: both)
    assert main.main(["--scope", "team", "--gemini-pause", "0", "--send-report"]) == 1
    err = capsys.readouterr().err
    assert "HTTP 500" in err and "Traceback" not in err and "secret-token" not in err
