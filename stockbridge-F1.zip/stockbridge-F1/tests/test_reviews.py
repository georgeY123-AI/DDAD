"""Review import, loading into SQLite and the precision query."""
import csv
import sqlite3

import pytest

import main
from src import reviews
from tests.fakes import CountingCall, factory_for
from tests.test_api_client import FakeSession


@pytest.fixture
def cases_csv(tmp_path):
    path = tmp_path / "cases.csv"
    path.write_text("CaseID,ReasonCodes\nPO-1,OVER_PURCHASE_LIMIT;STOCK_RUNS_OUT\nPO-2,SUPPLY_RISK\nPO-3,STOCK_RUNS_OUT\n",
                    encoding="utf-8")
    return path


def export(tmp_path, body, header="Title,ReviewDecision,ConfirmedCodes,ReviewerNotes"):
    path = tmp_path / "export.csv"
    path.write_text(header + "\n" + body, encoding="utf-8")
    return path


def test_clean_import(tmp_path, cases_csv):
    path = export(tmp_path, "PO-1,Confirmed,STOCK_RUNS_OUT;OVER_PURCHASE_LIMIT,ok\nPO-2,FalsePositive,,tolerated\nPO-3,NeedsMoreInfo,,unclear\n")
    result = reviews.import_reviews(path, cases_csv)
    assert result.problems == []
    assert result.rows[0] == {"CaseID": "PO-1", "ReviewDecision": "Confirmed",
                              "ConfirmedCodes": "OVER_PURCHASE_LIMIT;STOCK_RUNS_OUT",   # rule order, not typing order
                              "ReviewerNotes": "ok"}
    assert [r["ReviewDecision"] for r in result.rows] == ["Confirmed", "FalsePositive", "NeedsMoreInfo"]


def test_unknown_case_is_reported_and_skipped(tmp_path, cases_csv):
    result = reviews.import_reviews(export(tmp_path, "PO-9,Confirmed,SUPPLY_RISK,x\nPO-1,FalsePositive,,x\nPO-2,FalsePositive,,x\nPO-3,FalsePositive,,x\n"), cases_csv)
    assert any("PO-9" in p and "not in cases.csv" in p for p in result.problems)
    assert [r["CaseID"] for r in result.rows] == ["PO-1", "PO-2", "PO-3"]


def test_case_without_decision_is_reported(tmp_path, cases_csv):
    result = reviews.import_reviews(export(tmp_path, "PO-1,,,\nPO-2,FalsePositive,,x\n"), cases_csv)
    assert any("PO-1: no decision" in p for p in result.problems)
    assert any("PO-3: has no row" in p for p in result.problems)
    assert result.rows[0]["ReviewDecision"] == ""


def test_confirmed_code_that_is_not_a_reason_code_of_the_case(tmp_path, cases_csv):
    result = reviews.import_reviews(export(tmp_path, "PO-2,Confirmed,SUPPLY_RISK;STOCK_RUNS_OUT,x\n"), cases_csv)
    assert any("'STOCK_RUNS_OUT' is not one of the case's reason codes" in p for p in result.problems)
    assert result.rows[1]["ConfirmedCodes"] == "SUPPLY_RISK"


def test_decision_must_fit_the_codes(tmp_path, cases_csv):
    result = reviews.import_reviews(export(tmp_path, "PO-2,Confirmed,,x\nPO-3,FalsePositive,STOCK_RUNS_OUT,x\n"), cases_csv)
    assert any("PO-2" in p and "needs at least one confirmed code" in p for p in result.problems)
    assert any("PO-3" in p and "must not have confirmed codes" in p for p in result.problems)


def test_header_with_preamble_and_case_id_column_name(tmp_path, cases_csv):
    path = tmp_path / "export.csv"
    path.write_text("some title line\n\nCaseID,ReviewDecision,ConfirmedCodes,ReviewerNotes,Modified By\n"
                    "PO-1,FalsePositive,,n,A\nPO-2,FalsePositive,,n,B\nPO-3,FalsePositive,,n,A\n", encoding="utf-8")
    assert reviews.import_reviews(path, cases_csv).problems == []


def test_export_without_review_columns_gives_a_clear_error(tmp_path, cases_csv):
    path = tmp_path / "x.csv"
    path.write_text("Title,Severity\nPO-1,High\n", encoding="utf-8")
    with pytest.raises(ValueError, match="ReviewDecision"):
        reviews.import_reviews(path, cases_csv)


def test_reviews_csv_columns(tmp_path):
    reviews.write_reviews_csv(tmp_path / "r.csv", [{"CaseID": "PO-1", "ReviewDecision": "Confirmed",
                                                     "ConfirmedCodes": "A;B", "ReviewerNotes": "n"}])
    assert (tmp_path / "r.csv").read_text().splitlines() == ["CaseID,ReviewDecision,ConfirmedCodes,ReviewerNotes", "PO-1,Confirmed,A;B,n"]


# ---- through the whole run: reviews table, review_codes, precision -------------------------------------------------
@pytest.fixture
def out_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "OUTPUT_DIR", tmp_path)
    return tmp_path


def run(out_dir, **kw):
    return main.run("team", session=FakeSession(), call_factory=factory_for(CountingCall()), gemini_pause=0, **kw)


def make_export(out_dir, decide):
    """decide(case_row) -> (decision, confirmed codes)."""
    cases = list(csv.DictReader(open(out_dir / "cases.csv", encoding="utf-8")))
    path = out_dir / "export.csv"
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Title", "ReviewDecision", "ConfirmedCodes", "ReviewerNotes"])
        for c in cases:
            d, codes = decide(c)
            w.writerow([c["CaseID"], d, codes, "note"])
    return path


def test_import_then_precision_per_rule(out_dir):
    run(out_dir)                                                      # first run creates cases.csv
    # confirm every code except STOCK_RUNS_OUT; NeedsMoreInfo for the first case
    first = {"id": None}

    def decide(c):
        codes = [x for x in c["ReasonCodes"].split(";") if x != "STOCK_RUNS_OUT"]
        if first["id"] is None:
            first["id"] = c["CaseID"]
            return "NeedsMoreInfo", ""
        return ("Confirmed", ";".join(codes)) if codes else ("FalsePositive", "")
    s = run(out_dir, import_reviews=make_export(out_dir, decide))
    assert s["review_problems"] == [] and s["reviews_loaded"] == s["cases"]
    conn = sqlite3.connect(out_dir / "project.sqlite")
    assert conn.execute("SELECT COUNT(*) FROM reviews").fetchone()[0] == s["cases"]
    assert conn.execute("SELECT COUNT(*) FROM review_codes WHERE ReasonCode='STOCK_RUNS_OUT'").fetchone()[0] == 0
    prec = list(csv.DictReader(open(out_dir / "rule_precision.csv", encoding="utf-8")))
    assert [p["RuleID"] for p in prec] == sorted(p["RuleID"] for p in prec)
    r3 = next(p for p in prec if p["RuleID"] == "R3")
    assert r3["Confirmed"] == "0" and r3["Precision"] == "0.0" and int(r3["NotConfirmed"]) >= 10
    for p in prec:
        assert int(p["Flags"]) == int(p["Confirmed"]) + int(p["NotConfirmed"]) + int(p["Excluded"])
    r1 = next(p for p in prec if p["RuleID"] == "R1")
    assert r1["Precision"] == "1.0" and r1["NotConfirmed"] == "0"


def test_precision_definitions_on_a_tiny_example(out_dir):
    run(out_dir)
    flags = list(csv.DictReader(open(out_dir / "flags.csv", encoding="utf-8")))
    r2_cases = [f["RecordID"] for f in flags if f["RuleID"] == "R2"][:4]
    assert len(r2_cases) == 4

    def decide(c):
        cid = c["CaseID"]
        if cid == r2_cases[0]:
            return "Confirmed", "SUPPLY_RISK"
        if cid == r2_cases[1]:
            return "FalsePositive", ""
        if cid == r2_cases[2]:
            return "NeedsMoreInfo", ""
        return "FalsePositive", ""
    # the 4th R2 case: FalsePositive -> not confirmed; any other case: FalsePositive, unconfirmed
    run(out_dir, import_reviews=make_export(out_dir, decide))
    prec = {p["RuleID"]: p for p in csv.DictReader(open(out_dir / "rule_precision.csv", encoding="utf-8"))}
    r2 = prec["R2"]
    assert (r2["Confirmed"], r2["NotConfirmed"], r2["Excluded"]) == ("1", str(int(r2["Flags"]) - 2), "1")
    assert float(r2["Precision"]) == round(1 / (int(r2["Flags"]) - 1), 2)


def test_rerun_loads_reviews_and_skips_cases_that_no_longer_exist(out_dir):
    run(out_dir)
    reviews.write_reviews_csv(out_dir / "reviews.csv", [
        {"CaseID": "PO-9999", "ReviewDecision": "Confirmed", "ConfirmedCodes": "SUPPLY_RISK", "ReviewerNotes": "x"}])
    s = run(out_dir)
    assert any("PO-9999" in w for w in s["warnings"])
    conn = sqlite3.connect(out_dir / "project.sqlite")
    assert conn.execute("SELECT COUNT(*) FROM reviews").fetchone()[0] == 0


def test_no_reviews_file_means_no_precision_file(out_dir):
    run(out_dir)
    assert not (out_dir / "rule_precision.csv").exists() and not (out_dir / "reviews.csv").exists()
