"""Rules R1-R5: every boundary of the brief, flags, cases and Q4."""
import csv
import sqlite3
from fractions import Fraction

import pytest

import main
from src import db, reports, rules
from src.config import SQL_DIR
from src.rules import RuleInput, evaluate_rules
from tests.fakes import CountingCall, factory_for
from tests.test_api_client import FakeSession


def inp(**over):
    base = dict(record_id="PO-1", product_name="Alpha", supplier_name="Zeta", currency="EUR",
                preferred_currency="EUR", quantity=10, stock=100, demand=1, lead_days=7,
                max_order_huf=100_000, order_value_huf=1000, extraction_ok=True,
                delay_days=0, partial_delivery=False, price_increase_pct=0.0)
    base.update(over)
    return RuleInput(**base)


def ids(flags):
    return [f.rule_id for f in flags]


# ---- R1 OVER_PURCHASE_LIMIT (High) ------------------------------------------------------
def test_r1_equal_to_the_limit_is_not_flagged_one_forint_more_is():
    assert ids(evaluate_rules(inp(order_value_huf=100_000))) == []
    flags = evaluate_rules(inp(order_value_huf=100_001))
    assert ids(flags) == ["R1"] and flags[0].reason_code == "OVER_PURCHASE_LIMIT" and flags[0].severity == "High"


# ---- R2 SUPPLY_RISK (Medium) ------------------------------------------------------------------
@pytest.mark.parametrize("delay,partial,flagged", [(6, False, False), (7, False, True), (8, False, True),
                                                   (0, True, True), (6, True, True), (0, False, False)])
def test_r2_delay_boundary_and_partial_delivery(delay, partial, flagged):
    assert (ids(evaluate_rules(inp(delay_days=delay, partial_delivery=partial))) == ["R2"]) is flagged


def test_r2_skipped_when_extraction_failed():
    failed = inp(extraction_ok=False, delay_days=None, partial_delivery=None, price_increase_pct=None)
    assert ids(evaluate_rules(failed)) == []


# ---- R3 STOCK_RUNS_OUT (High) ---------------------------------------------------------------------
def test_r3_equality_is_not_flagged_one_piece_less_is():
    assert ids(evaluate_rules(inp(stock=10, demand=7, lead_days=10))) == []          # 70 = 70
    flags = evaluate_rules(inp(stock=9, demand=7, lead_days=10))                      # 63 < 70
    assert ids(flags) == ["R3"] and flags[0].severity == "High" and flags[0].reason_code == "STOCK_RUNS_OUT"


def test_r3_zero_demand_is_never_flagged():
    assert ids(evaluate_rules(inp(stock=0, demand=0, lead_days=21))) == []


def test_r3_gap_in_days():
    assert rules.r3_gap_days(13, 14, 7) == Fraction(1, 2)          # 7 - 91/14
    assert rules.r3_gap_days(5, 0, 7) is None


@pytest.mark.parametrize("stock,tolerance,flagged", [
    (13, 0, True),          # default: any gap flags (gap 0.5)
    (13, "0.5", False),     # gap exactly 0.5 is tolerated
    (12, "0.5", True),      # gap 1.0 is still flagged
    (13, 0.4, True),
])
def test_r3_tolerance_parameter(stock, tolerance, flagged):
    i = inp(stock=stock, demand=14, lead_days=7)
    assert (ids(evaluate_rules(i, r3_tolerance=tolerance)) == ["R3"]) is flagged


def test_default_tolerance_equals_the_brief_rule_for_many_values():
    for stock in range(0, 40):
        for demand in range(0, 12):
            for lead in (3, 7, 14):
                i = inp(stock=stock, demand=demand, lead_days=lead)
                assert rules.r3_matches(i) == (stock * 7 < demand * lead)


# ---- R4 UNEXPECTED_CURRENCY (Medium) -------------------------------------------------------------------
def test_r4_currency_differs_from_the_preferred_one():
    assert ids(evaluate_rules(inp(currency="EUR", preferred_currency="EUR"))) == []
    flags = evaluate_rules(inp(currency="USD", preferred_currency="EUR"))
    assert ids(flags) == ["R4"] and flags[0].severity == "Medium" and flags[0].risk_score == 0.6


# ---- R5 PRICE_RISE_LARGE_ORDER (Medium) -----------------------------------------------------------------------
@pytest.mark.parametrize("pct,qty,flagged", [(5, 50, True), (4.99, 50, False), (5, 49, False),
                                             (8, 100, True), (0, 500, False)])
def test_r5_boundaries(pct, qty, flagged):
    assert (ids(evaluate_rules(inp(price_increase_pct=pct, quantity=qty))) == ["R5"]) is flagged


def test_r5_skipped_when_extraction_failed():
    failed = inp(extraction_ok=False, delay_days=None, partial_delivery=None, price_increase_pct=None, quantity=999)
    assert ids(evaluate_rules(failed)) == []


# ---- scope ---------------------------------------------------------------------------------------------
def test_solo_scope_only_evaluates_r1_to_r3():
    i = inp(currency="USD", price_increase_pct=9, quantity=100, order_value_huf=200_000)
    assert ids(evaluate_rules(i, scope="team")) == ["R1", "R4", "R5"]
    assert ids(evaluate_rules(i, scope="solo")) == ["R1"]


# ---- flags and cases ----------------------------------------------------------------------------------------
def test_flags_are_sorted_and_risk_scores_are_fixed():
    inputs = [inp(record_id="PO-2", order_value_huf=200_000, currency="USD"), inp(record_id="PO-1", delay_days=9)]
    flags = rules.build_flags(inputs)
    assert [(f.record_id, f.rule_id, f.risk_score) for f in flags] == [
        ("PO-1", "R2", 0.6), ("PO-2", "R1", 0.9), ("PO-2", "R4", 0.6)]


def test_case_severity_risk_codes_status_and_sort_order():
    inputs = [inp(record_id="PO-3", delay_days=9),                                         # Medium only
              inp(record_id="PO-2", order_value_huf=200_000, currency="USD"),            # High + Medium
              inp(record_id="PO-1", order_value_huf=200_000),                             # High only
              inp(record_id="PO-4")]                                                        # no flag
    cases = rules.build_cases(rules.build_flags(inputs), inputs)
    assert [c["CaseID"] for c in cases] == ["PO-1", "PO-2", "PO-3"]                       # RiskScore desc, then CaseID
    two = cases[1]
    assert two["Severity"] == "High" and two["RiskScore"] == 0.9
    assert two["ReasonCodes"] == "OVER_PURCHASE_LIMIT;UNEXPECTED_CURRENCY"                 # rule order, R1 first
    assert all(c["Status"] == "New" for c in cases)
    assert cases[2]["Severity"] == "Medium" and cases[2]["RiskScore"] == 0.6 and cases[2]["delay_days"] == 9
    assert list(cases[0]) == rules.CASE_COLUMNS


def test_failed_extraction_leaves_delay_days_empty():
    i = inp(order_value_huf=200_000, extraction_ok=False, delay_days=None, partial_delivery=None, price_increase_pct=None)
    case, = rules.build_cases(rules.build_flags([i]), [i])
    assert case["delay_days"] == ""


def test_csv_files_have_the_specified_columns(tmp_path):
    i = inp(order_value_huf=200_000)
    flags = rules.build_flags([i])
    rules.write_flags_csv(tmp_path / "flags.csv", flags)
    rules.write_cases_csv(tmp_path / "cases.csv", rules.build_cases(flags, [i]))
    assert (tmp_path / "flags.csv").read_text().splitlines() == [
        "RecordID,RuleID,ReasonCode,Severity,RiskScore", "PO-1,R1,OVER_PURCHASE_LIMIT,High,0.9"]
    assert (tmp_path / "cases.csv").read_text().splitlines()[0] == (
        "CaseID,Severity,RiskScore,ReasonCodes,Status,ProductName,SupplierName,Currency,OrderValueHUF,delay_days")


# ---- Q4 --------------------------------------------------------------------------------------------------------
def test_q4_counts_a_proposal_once_even_with_several_flags(tmp_path):
    products = [{"ProductID": "P-1", "ProductName": "A", "Category": "Cat1", "TargetStock": "1", "MaxOrderHUF": "10"},
                {"ProductID": "P-2", "ProductName": "B", "Category": "Cat2", "TargetStock": "1", "MaxOrderHUF": "10"}]
    suppliers = [{"SupplierID": "S-1", "SupplierName": "S", "Country": "HU", "PreferredCurrency": "HUF", "LeadDays": "1"}]

    def pur(pid, prod):
        return {"PurchaseID": pid, "ProductID": prod, "SupplierID": "S-1", "OrderDate": "2026-09-14", "Quantity": "1",
                "UnitPrice": "1", "Currency": "HUF", "StockOnHand": "1", "WeeklyDemand": "1", "SupplierMessage": "m"}
    purchases = [pur("PO-1", "P-1"), pur("PO-2", "P-1"), pur("PO-3", "P-2")]
    cases = [
        {"CaseID": "PO-1", "Severity": "High", "RiskScore": 0.9, "ReasonCodes": "A;B", "Status": "New", "ProductName": "A",
         "SupplierName": "S", "Currency": "HUF", "OrderValueHUF": 1, "delay_days": ""},
        {"CaseID": "PO-3", "Severity": "Medium", "RiskScore": 0.6, "ReasonCodes": "C", "Status": "New", "ProductName": "B",
         "SupplierName": "S", "Currency": "HUF", "OrderValueHUF": 1, "delay_days": 2}]
    flags = [rules.Flag("PO-1", "R1", "A", "High", 0.9), rules.Flag("PO-1", "R2", "B", "Medium", 0.6),
             rules.Flag("PO-3", "R2", "C", "Medium", 0.6)]
    path = tmp_path / "t.sqlite"
    db.build_database(path, products, suppliers, purchases, [], {"PO-1": 1, "PO-2": 1, "PO-3": 1}, [], flags, cases)
    reports.run_reports(path, SQL_DIR / "queries.sql", tmp_path / "out")
    q4 = list(csv.reader(open(tmp_path / "out" / "Q4.csv", encoding="utf-8")))
    assert q4 == [["Category", "ProposalCount", "CaseCount", "HighCaseCount"], ["Cat1", "2", "1", "1"], ["Cat2", "1", "1", "0"]]


# ---- the whole run --------------------------------------------------------------------------------------------------
@pytest.fixture
def out_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "OUTPUT_DIR", tmp_path)
    return tmp_path


def test_team_run_writes_flags_cases_and_tables(out_dir):
    s = main.run("team", session=FakeSession(), call_factory=factory_for(CountingCall()), gemini_pause=0)
    flags = list(csv.DictReader(open(out_dir / "flags.csv", encoding="utf-8")))
    cases = list(csv.DictReader(open(out_dir / "cases.csv", encoding="utf-8")))
    assert [(f["RecordID"], f["RuleID"]) for f in flags] == sorted((f["RecordID"], f["RuleID"]) for f in flags)
    assert len(cases) == len({f["RecordID"] for f in flags}) == s["cases"]
    assert sum(s["flag_counts"].values()) == len(flags)
    conn = sqlite3.connect(out_dir / "project.sqlite")
    assert conn.execute("SELECT COUNT(*) FROM flags").fetchone()[0] == len(flags)
    assert conn.execute("SELECT COUNT(*) FROM cases").fetchone()[0] == len(cases)
    assert conn.execute("PRAGMA foreign_key_check").fetchall() == []
    assert (out_dir / "sql" / "Q4.csv").exists()


def test_r3_flags_of_the_run_match_q3(out_dir):
    main.run("team", session=FakeSession(), call_factory=factory_for(CountingCall()), gemini_pause=0)
    q3 = {r[0] for r in list(csv.reader(open(out_dir / "sql" / "Q3.csv", encoding="utf-8")))[1:]}
    r3 = {f["RecordID"] for f in csv.DictReader(open(out_dir / "flags.csv", encoding="utf-8")) if f["RuleID"] == "R3"}
    assert q3 == r3 and len(q3) == 11
