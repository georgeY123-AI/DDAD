"""R3 analysis, threshold suggestion, tuned run and the before/after table."""
import csv
from fractions import Fraction

import pytest

import main
from src import rules, tuning
from src.rules import RuleInput
from tests.fakes import CountingCall, factory_for
from tests.test_api_client import FakeSession


def r3_input(record_id, gap_stock, demand=14, lead=7):
    """Record whose R3 gap is lead - stock*7/demand."""
    return RuleInput(record_id=record_id, product_name="P", supplier_name="S", currency="EUR", preferred_currency="EUR",
                     quantity=1, stock=gap_stock, demand=demand, lead_days=lead, max_order_huf=10**9,
                     order_value_huf=1, extraction_ok=True, delay_days=0, partial_delivery=False,
                     price_increase_pct=0.0)


def review(case, decision, codes=""):
    return {"CaseID": case, "ReviewDecision": decision, "ConfirmedCodes": codes, "ReviewerNotes": "n"}


# stock 13 -> gap 0.5 ; stock 12 -> gap 1.0 ; stock 11 -> 1.5 ; stock 14 -> 0 (not flagged) ; stock 6 -> 4.0
INPUTS = [r3_input("PO-1", 13), r3_input("PO-2", 12), r3_input("PO-3", 11), r3_input("PO-4", 14), r3_input("PO-5", 6)]
REVIEWS = [review("PO-1", "FalsePositive"), review("PO-2", "Confirmed", "STOCK_RUNS_OUT"),
           review("PO-3", "Confirmed", "STOCK_RUNS_OUT"), review("PO-5", "NeedsMoreInfo")]


def test_analysis_rows_have_gap_and_outcome():
    rows = tuning.analysis_rows(INPUTS, REVIEWS)
    assert [(r["CaseID"], r["GapDays"], r["Outcome"]) for r in rows] == [
        ("PO-1", 0.5, "not_confirmed"), ("PO-2", 1.0, "confirmed"), ("PO-3", 1.5, "confirmed"), ("PO-5", 4.0, "excluded")]


def test_suggestion_removes_unconfirmed_and_keeps_every_confirmed_flag():
    s = tuning.suggest_tolerance(tuning.analysis_rows(INPUTS, REVIEWS))
    assert s.tolerance == "0.75" and s.max_not_confirmed == 0.5 and s.min_confirmed == 1.0
    tol = tuning.parse_tolerance(s.tolerance)
    kept = {f.record_id for i in INPUTS for f in rules.evaluate_rules(i, r3_tolerance=tol)}
    assert "PO-1" not in kept and {"PO-2", "PO-3"} <= kept


def test_suggestion_when_flags_overlap():
    rows = [{"CaseID": "A", "GapDays": 1.0, "Outcome": "not_confirmed"}, {"CaseID": "B", "GapDays": 0.5, "Outcome": "confirmed"}]
    s = tuning.suggest_tolerance(rows)
    assert s.tolerance is None and "overlap" in s.message


def test_suggestion_when_nothing_to_remove_or_nothing_confirmed():
    assert tuning.suggest_tolerance([{"CaseID": "A", "GapDays": 1.0, "Outcome": "confirmed"}]).tolerance is None
    assert tuning.suggest_tolerance([{"CaseID": "A", "GapDays": 1.0, "Outcome": "not_confirmed"}]).tolerance is None


@pytest.mark.parametrize("text,ok", [("0.5", True), ("0", True), ("2", True), ("1/3", True), ("-1", False), ("abc", False), ("", False)])
def test_parse_tolerance(text, ok):
    if ok:
        assert tuning.parse_tolerance(text) >= 0
    else:
        with pytest.raises(ValueError):
            tuning.parse_tolerance(text)


def test_setting_text():
    assert tuning.setting_text(0) == "tolerance = 0 days"
    assert tuning.setting_text(Fraction(1, 2)) == "tolerance = 0.5 days"
    assert tuning.setting_text("0.75") == "tolerance = 0.75 days"


def test_metrics_precision_and_lost_confirmed_flags():
    before = rules.build_flags(INPUTS)
    after = rules.build_flags(INPUTS, r3_tolerance="0.75")
    assert tuning.rule_metrics(before, REVIEWS) == {"RuleFlags": 4, "ConfirmedFlags": 2, "NotConfirmedFlags": 1, "Precision": 0.67}
    assert tuning.rule_metrics(after, REVIEWS) == {"RuleFlags": 3, "ConfirmedFlags": 2, "NotConfirmedFlags": 0, "Precision": 1.0}
    assert tuning.lost_confirmed_flags(before, after, REVIEWS) == []
    too_strict = rules.build_flags(INPUTS, r3_tolerance="1.2")
    assert tuning.lost_confirmed_flags(before, too_strict, REVIEWS) == ["PO-2"]


def test_precision_is_empty_when_nothing_was_reviewed():
    assert tuning.rule_metrics(rules.build_flags(INPUTS), [])["Precision"] == ""


def test_before_after_table_has_the_specified_columns_and_rows(tmp_path):
    before, after = rules.build_flags(INPUTS), rules.build_flags(INPUTS, r3_tolerance="0.75")
    rows = tuning.before_after_rows(before, rules.build_cases(before, INPUTS), after, rules.build_cases(after, INPUTS),
                                    REVIEWS, "0.75")
    tuning.write_before_after_csv(tmp_path / "t.csv", rows)
    lines = (tmp_path / "t.csv").read_text().splitlines()
    assert lines[0] == "Version,RuleID,Setting,RuleFlags,ConfirmedFlags,NotConfirmedFlags,Precision,TotalCases"
    assert lines[1] == "before,R3,tolerance = 0 days,4,2,1,0.67,4"
    assert lines[2] == "after,R3,tolerance = 0.75 days,3,2,0,1.0,3"


def test_chart_is_written(tmp_path):
    rows = tuning.analysis_rows(INPUTS, REVIEWS)
    assert tuning.plot_analysis(rows, tmp_path / "r3.png", "0.75") is True
    assert (tmp_path / "r3.png").stat().st_size > 1000


# ---- the whole run: default output stays the brief's, tuned goes to output/tuned/ ---------------------------------------
@pytest.fixture
def out_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "OUTPUT_DIR", tmp_path)
    return tmp_path


def go(out_dir, **kw):
    return main.run("team", session=FakeSession(), call_factory=factory_for(CountingCall()), gemini_pause=0, **kw)


def review_everything(out_dir, tolerated_gap=0.5):
    """Reviewers follow the guideline: R3 is not confirmed when the gap is at most the business tolerance."""
    go(out_dir)
    gaps = {r["CaseID"]: r["GapDays"] for r in tuning.analysis_rows(
        _inputs(out_dir), [])}
    cases = list(csv.DictReader(open(out_dir / "cases.csv", encoding="utf-8")))
    path = out_dir / "export.csv"
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Title", "ReviewDecision", "ConfirmedCodes", "ReviewerNotes"])
        for c in cases:
            codes = [x for x in c["ReasonCodes"].split(";")
                     if not (x == "STOCK_RUNS_OUT" and gaps[c["CaseID"]] <= tolerated_gap)]
            w.writerow([c["CaseID"], "Confirmed" if codes else "FalsePositive", ";".join(codes), "n"])
    return path


def _inputs(out_dir):
    # rebuild the rule inputs of the fake run from its own output files
    from src import db
    from src.config import DATA_DIR
    purchases = {r["PurchaseID"]: r for r in db.read_csv_rows(DATA_DIR / "purchases_team.csv") if r["PurchaseID"]}
    suppliers = {s["SupplierID"]: s for s in db.read_csv_rows(DATA_DIR / "suppliers.csv")}
    flagged = {f["RecordID"] for f in csv.DictReader(open(out_dir / "flags.csv", encoding="utf-8")) if f["RuleID"] == "R3"}
    out = []
    for pid in sorted(flagged):
        row = purchases[pid]
        out.append(RuleInput(record_id=pid, product_name="", supplier_name="", currency=row["Currency"], preferred_currency="",
                             quantity=int(row["Quantity"]), stock=int(row["StockOnHand"]), demand=int(row["WeeklyDemand"]),
                             lead_days=int(suppliers[row["SupplierID"]]["LeadDays"]), max_order_huf=0, order_value_huf=0))
    return out


def test_tuned_run_writes_tuned_folder_before_after_and_keeps_default_output(out_dir):
    export = review_everything(out_dir)
    s = go(out_dir, import_reviews=export)
    assert s["suggestion"].tolerance is not None
    default_flags = (out_dir / "flags.csv").read_bytes()
    default_cases = (out_dir / "cases.csv").read_bytes()
    t = go(out_dir, r3_tolerance="0.5")
    assert (out_dir / "flags.csv").read_bytes() == default_flags and (out_dir / "cases.csv").read_bytes() == default_cases
    assert t["tuned"]["lost_confirmed"] == []
    tuned_flags = list(csv.DictReader(open(out_dir / "tuned" / "flags.csv", encoding="utf-8")))
    default = list(csv.DictReader(open(out_dir / "flags.csv", encoding="utf-8")))
    assert sum(f["RuleID"] == "R3" for f in tuned_flags) == 6 and sum(f["RuleID"] == "R3" for f in default) == 11
    assert all(f in default for f in tuned_flags if f["RuleID"] != "R3")
    ba = list(csv.DictReader(open(out_dir / "tuning_before_after.csv", encoding="utf-8")))
    assert [r["Version"] for r in ba] == ["before", "after"] and ba[0]["Setting"] == "tolerance = 0 days"
    assert ba[1]["Setting"] == "tolerance = 0.5 days" and float(ba[1]["Precision"]) == 1.0
    assert int(ba[1]["TotalCases"]) <= int(ba[0]["TotalCases"])
    assert (out_dir / "r3_analysis.csv").exists() and (out_dir / "r3_analysis.png").exists()


def test_tuned_run_without_reviews_still_writes_tuned_files_and_warns(out_dir):
    t = go(out_dir, r3_tolerance="0.5")
    assert (out_dir / "tuned" / "flags.csv").exists() and not (out_dir / "tuning_before_after.csv").exists()
    assert any("no reviews.csv" in w for w in t["warnings"])


def test_bad_tolerance_stops_before_any_work(out_dir):
    with pytest.raises(ValueError):
        go(out_dir, r3_tolerance="-2")
    assert not (out_dir / "rejected_rows.csv").exists()


def test_tuned_run_makes_no_new_calls(out_dir):
    go(out_dir)
    calls = CountingCall()
    s2 = FakeSession()
    main.run("team", session=s2, call_factory=factory_for(calls), gemini_pause=0, r3_tolerance="0.5")
    assert calls.calls == [] and s2.calls == []
