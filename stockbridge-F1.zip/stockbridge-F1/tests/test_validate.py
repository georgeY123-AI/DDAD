"""Tests for validation: every reason code, the check order and the boundaries."""
import pytest

from src import validate
from src.config import DATA_DIR

PRODUCTS = {"P-101", "P-102"}
SUPPLIERS = {"SUP-1", "SUP-2"}


def good(**over):
    row = {
        "PurchaseID": "PO-1", "ProductID": "P-101", "SupplierID": "SUP-1",
        "OrderDate": "2026-09-14", "Quantity": "10", "UnitPrice": "12.5",
        "Currency": "EUR", "StockOnHand": "5", "WeeklyDemand": "7",
        "SupplierMessage": "No delay expected.",
    }
    row.update(over)
    return row


def reason(row, seen=None):
    return validate.reason_for(row, seen or set(), PRODUCTS, SUPPLIERS)


def test_valid_row_passes():
    assert reason(good()) is None


# ---- one test per reason code -------------------------------------------
def test_missing_id():
    assert reason(good(PurchaseID="")) == "MISSING_ID"


def test_duplicate_id():
    assert reason(good(), seen={"PO-1"}) == "DUPLICATE_ID"


@pytest.mark.parametrize("field,value", [("ProductID", "UNKNOWN-01"), ("ProductID", ""),
                                         ("SupplierID", "SUP-9"), ("SupplierID", "")])
def test_unknown_reference(field, value):
    assert reason(good(**{field: value})) == "UNKNOWN_REFERENCE"


@pytest.mark.parametrize("date", ["2026-02-30", "", "2026/09/14", "14-09-2026", "2026-9-14", "2026-13-01"])
def test_invalid_date(date):
    assert reason(good(OrderDate=date)) == "INVALID_DATE"


def test_future_or_past_dates_are_not_rejected():
    assert reason(good(OrderDate="2030-01-01")) is None
    assert reason(good(OrderDate="2000-01-01")) is None


# ---- INVALID_VALUE and its boundaries --------------------------------------
@pytest.mark.parametrize("field,value", [
    ("Quantity", "0"), ("Quantity", "-3"), ("Quantity", "10001"), ("Quantity", "1.5"), ("Quantity", ""),
    ("UnitPrice", "12,5"), ("UnitPrice", "0"), ("UnitPrice", "0.009"), ("UnitPrice", "1000000.01"),
    ("UnitPrice", "abc"), ("UnitPrice", ""),
    ("Currency", "eur"), ("Currency", "JPY"), ("Currency", ""),
    ("StockOnHand", "-1"), ("StockOnHand", "100001"),
    ("WeeklyDemand", "100001"), ("WeeklyDemand", "x"),
])
def test_invalid_value(field, value):
    assert reason(good(**{field: value})) == "INVALID_VALUE"


@pytest.mark.parametrize("field,value", [
    ("Quantity", "1"), ("Quantity", "10000"),
    ("UnitPrice", "0.01"), ("UnitPrice", "1000000"), ("UnitPrice", "12"),
    ("StockOnHand", "0"), ("StockOnHand", "100000"),
    ("WeeklyDemand", "0"), ("WeeklyDemand", "100000"),
])
def test_valid_boundaries(field, value):
    assert reason(good(**{field: value})) is None


# ---- order of the checks ---------------------------------------------------
def test_first_failed_check_wins():
    assert reason(good(PurchaseID="", ProductID="X", OrderDate="bad", Quantity="-1")) == "MISSING_ID"
    assert reason(good(ProductID="X", OrderDate="bad"), seen={"PO-1"}) == "DUPLICATE_ID"
    assert reason(good(ProductID="X", OrderDate="bad", Quantity="-1")) == "UNKNOWN_REFERENCE"
    assert reason(good(OrderDate="2026-02-30", Quantity="-1")) == "INVALID_DATE"


# ---- stripping, duplicates, source rows ------------------------------------
def test_spaces_are_stripped(tmp_path):
    f = tmp_path / "r.csv"
    f.write_text("PurchaseID,Quantity\n  PO-1  , 5 \n", encoding="utf-8")
    (line, row), = list(validate.read_records(f))
    assert line == 2 and row == {"PurchaseID": "PO-1", "Quantity": "5"}


def test_duplicate_of_a_rejected_row_is_still_a_duplicate():
    rows = [(2, good(PurchaseID="PO-9", Quantity="-1")), (3, good(PurchaseID="PO-9"))]
    accepted, rejected = validate.validate_records(rows, PRODUCTS, SUPPLIERS)
    assert [(r.source_row, r.reason_code) for r in rejected] == [(2, "INVALID_VALUE"), (3, "DUPLICATE_ID")]
    assert accepted == []


def test_earlier_row_keeps_its_own_result():
    rows = [(2, good(PurchaseID="PO-9")), (3, good(PurchaseID="PO-9"))]
    accepted, rejected = validate.validate_records(rows, PRODUCTS, SUPPLIERS)
    assert [a[0] for a in accepted] == [2]
    assert [(r.source_row, r.reason_code) for r in rejected] == [(3, "DUPLICATE_ID")]


def test_write_rejected_csv(tmp_path):
    out = tmp_path / "rejected_rows.csv"
    validate.write_rejected_csv(out, [validate.Rejected(9, "", "MISSING_ID")])
    assert out.read_text(encoding="utf-8").splitlines() == ["SourceRow,RecordID,ReasonCode", "9,,MISSING_ID"]


# ---- the real data files ---------------------------------------------------
def _run(scope_file):
    products = validate.load_keys(DATA_DIR / "products.csv", "ProductID")
    suppliers = validate.load_keys(DATA_DIR / "suppliers.csv", "SupplierID")
    recs = list(validate.read_records(DATA_DIR / scope_file))
    accepted, rejected = validate.validate_records(recs, products, suppliers)
    return len(recs), len(accepted), [(r.source_row, r.record_id, r.reason_code) for r in rejected]


def test_team_file_counts_and_reasons():
    total, acc, rej = _run("purchases_team.csv")
    assert (total, acc) == (66, 60)
    assert rej == [(9, "", "MISSING_ID"), (21, "PO-5006", "DUPLICATE_ID"),
                   (28, "PO-5063", "UNKNOWN_REFERENCE"), (40, "PO-5064", "INVALID_DATE"),
                   (49, "PO-5065", "INVALID_VALUE"), (57, "PO-5066", "INVALID_VALUE")]


def test_solo_file_counts_and_reasons():
    total, acc, rej = _run("purchases_solo.csv")
    assert (total, acc) == (24, 18)
    assert [c for _, _, c in rej] == ["MISSING_ID", "DUPLICATE_ID", "UNKNOWN_REFERENCE",
                                      "INVALID_DATE", "INVALID_VALUE", "INVALID_VALUE"]
